<?php
session_start();
error_reporting(0);
include "inc/connection.php";
if( !isset($_SESSION['admin_id']) )
{
header("Location: sign-in.php");
}
?>
<?php    
$sql="SELECT * FROM  staffs  WHERE staff_id='".$_GET['staffid']."'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
?>
<table width="98%" border="0" align="center" cellpadding="1" cellspacing="1">
<tr>
<td  align="left" class="toprk" >
<div style="padding: 25px;">
<h3>Staff Details :</h3>

<p style="font-size:15px;"><strong>Position :</strong> <?php $positionqry="select * from positions where position_id='".$row['position_id']."'";
$positionres=mysqli_query($con,$positionqry);
$positionrow=mysqli_fetch_array($positionres);
echo $positionrow['position'];
?></p>

<p style="font-size:15px;"><strong>Full Name :</strong> <?php echo $row['fullname']; ?></p>
<p style="font-size:15px;"><strong>Email ID :</strong> <?php echo $row['email']; ?></p>
<p style="font-size:15px;"><strong>Address :</strong> <?php echo $row['address']; ?></p>
<p style="font-size:15px;"><strong>Entitle :</strong> <?php echo $row['entitle']; ?></p>

</div>
</td>
</tr>
</table>
