<?php
session_start();
include "inc/connection.php";
//require_once('../PHPMailer/PHPMailerAutoload.php');
error_reporting(0);

/* change admin department status start */
if($_POST['action'] == 'change_department_status'){
	$department_id = $_POST['department_id'];
	$department_status = $_POST['department_status'];
	if($department_status == "activate"){
		$qry="UPDATE departments SET status='1'  WHERE department_id='".$_POST['department_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE departments SET status='0'  WHERE department_id='".$_POST['department_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* change admin department status end */


/* delete department start */
if($_POST['action'] == 'delete_department'){
	$qry = "DELETE FROM departments WHERE department_id='".$_POST['department_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete department start */



/* STAFF START */
/* delete staff start */
if($_POST['action'] == 'delete_staff'){
	$qry = "DELETE FROM staffs WHERE staff_id='".$_POST['staff_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete staff start */

/* change admin staff start */
if($_POST['action'] == 'change_staff_status'){
	$staff_id = $_POST['staff_id'];
	$staff_status = $_POST['staff_status'];
	if($staff_status == "activate"){
		$qry="UPDATE staffs SET status='1'  WHERE staff_id='".$_POST['staff_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE staffs SET status='0'  WHERE staff_id='".$_POST['staff_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* change admin staff end */
/* STAFF END */


/* VACANCY START */
/* delete vacancy start */
if($_POST['action'] == 'delete_vacancy'){
	$qry = "DELETE FROM vacancies WHERE vacancy_id='".$_POST['vacancy_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete vacancy start */

/* change admin vacancy start */
if($_POST['action'] == 'change_vacancy_status'){
	$vacancy_id = $_POST['vacancy_id'];
	$vacancy_status = $_POST['vacancy_status'];
	if($vacancy_status == "activate"){
		$qry="UPDATE vacancies SET status='1'  WHERE vacancy_id='".$_POST['vacancy_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE vacancies SET status='0'  WHERE vacancy_id='".$_POST['vacancy_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* change admin vacancy end */
/* VACANCY END */

/* POSITION START */
/* delete position start */
if($_POST['action'] == 'delete_position'){
	$qry = "DELETE FROM positions WHERE position_id='".$_POST['position_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete position start */

/* change admin position start */
if($_POST['action'] == 'change_position_status'){
	$position_id = $_POST['position_id'];
	$position_status = $_POST['position_status'];
	if($position_status == "activate"){
		$qry="UPDATE positions SET status='1'  WHERE position_id='".$_POST['position_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE positions SET status='0'  WHERE position_id='".$_POST['position_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* change admin position end */
/* POSITION END */

/* CONTRACT START */
/* delete contract start */
if($_POST['action'] == 'delete_contract'){
	$qry = "DELETE FROM contracts WHERE contract_id='".$_POST['contract_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete contract start */

/* change admin contract start */
if($_POST['action'] == 'change_contract_status'){
	$contract_id = $_POST['contract_id'];
	$contract_status = $_POST['contract_status'];
	if($contract_status == "activate"){
		$qry="UPDATE contracts SET status='1'  WHERE contract_id='".$_POST['contract_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE contracts SET status='0'  WHERE contract_id='".$_POST['contract_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* change admin contract end */
/* CONTRACT END */

/* APPLICATION START */
/* delete application start */
if($_POST['action'] == 'delete_application'){
	$qry = "DELETE FROM applications WHERE application_id='".$_POST['application_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete application start */

/* shortlist application start */
if($_POST['action'] == 'shortlist_applicaton'){
	$application_id = $_POST['application_id'];
	$application_status = $_POST['application_status'];
	if($application_status == "activate"){
		$qry="UPDATE applications SET is_shortlisted=1, shortlisted_by='".$_SESSION['admin_id']."'  WHERE application_id='".$_POST['application_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE applications SET is_shortlisted=0, shortlisted_by='".$_SESSION['admin_id']."'  WHERE application_id='".$_POST['application_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* shortlist application end */

/* approve start */
if($_POST['action'] == 'approved_application'){
	$application_id = $_POST['application_id'];
	$application_status = $_POST['application_status'];
	if($application_status == "activate"){
		$qry="UPDATE applications SET is_approved=1, approved_by='".$_SESSION['admin_id']."'  WHERE application_id='".$_POST['application_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE applications SET is_approved=0, approved_by='".$_SESSION['admin_id']."'  WHERE application_id='".$_POST['application_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* approve end */

/* APPLICATION END */




?>