<div class="siteheader">


  <nav class="navbar navbar-inverse">
    <div class="container">

      <ul class="nav navbar-nav lsmain navbar-left">
        <li><div class="logo"> <a href="index.php" style="font-size: 25px;" > <img src="images/logo-updates.png"> </a> </div></li>

<!--     <div class="navbar-header for-mobile">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>                        
</button>

</div> -->

<form method="get" class="ls_home_top_search" action="#" id="course-search">
  <input type="text" name="term" value="" placeholder="Course Search">
  <button><i class="fa fa-search" aria-hidden="true"></i></button>
</form>



</ul>

<div class="navbar-header for-desktop">
  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>                        
  </button>
</div>

<div class="collapse navbar-collapse" id="myNavbar">
  <div class="ls_menus_grad">
    <ul class="nav navbar-nav lssub">
      <li class="active"><a href="index.php">Home</a></li>

      <?php
      if(isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id'])){
        ?>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Position <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="position.php">Add Position</a></li>
            <li><a href="position-list.php">Position List</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Staffs <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="staff.php">Add Staff</a></li>
            <li><a href="staffs-list.php">Staff List</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Contracts <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="contract.php">Add Contract</a></li>
            <li><a href="contract-list.php">Contract List</a></li>
          </ul>
        </li>

        <?php
      }
      ?>

    </ul>
    <ul class="nav navbar-nav navbar-right">
      <?php
      if(isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id'])){
        ?>

        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $_SESSION['admin_name']; ?> <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li></li>
            <li><a href="chng-password.php">Change Password</a></li>
            <li><a href="update-email.php">Update Emails</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </li>

      <?php }else{ ?>
        <li><a href="sign-in.php">Sign in</a></li>
      <?php } ?>

    </ul>
  </div>
</div>
</div>
</nav>

</div>
</div>