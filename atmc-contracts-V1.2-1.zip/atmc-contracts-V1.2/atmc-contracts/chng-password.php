<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
header("Location: sign-in.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
</head>
<body>

	<?php
	include "primary-menu.php";
	?> 
	<div class="container">
		<div class="ls_content">
			<!-- content start -->

			<div class="row">

				<div class="col-md-8 col-md-offset-2">

					<div class="ls_over_to_you ls_sign_in text-center">
						<h1>Change  Password</h1>
						<div class="registration_form">
							<div>
								<p>Update your password below</p>
							</div>

							<form  class="adminform" name="chgPassword" id="chgPassword" onSubmit="return Validate();" action="check-password.php" method="post" enctype="multipart/form-data" autocomplete="off" >
								<div id="errmsg" style="font-size:12px;color:#F00;margin-bottom:0;">
									<?php 
									if(isset($_REQUEST['er']))
									{
										$er=$_REQUEST["er"]; 
										if ($er=='1')
										{
											echo "Sorry! Your Login might be incorrect!";
										} 
										if ($er=='2')
										{
											echo "Sorry! Your Old Password might be incorrect!";
										} 
										if ($er=='3')
										{
											echo "Your Password Changed Successfully!";
										} 
									}
									?>
								</div>

								<div class="form-group"> <b style="font-weight:900;font-size:20px"><?php echo $_SESSION['admin_name']; ?></b> </div>

								<div class="form-group">
									<label>Old Password</label>
									<input class="form-control" type="password" placeholder="Old Password" name="oldPassword" value="" maxlength="30">
								</div>

								<div class="form-group">
									<label>New Password</label>
									<input class="form-control" type="password" placeholder="New Password" name="newPassword" value="" maxlength="30">
								</div>

								<div class="form-group">
									<label>Confirm Password</label>
									<input class="form-control" type="password" placeholder="Confirm Password" name="confirmPassword"  value="" maxlength="30">
								</div>


								<button type="submit" class="btn btn-default front_button">Update</button>


							</form>

						</div>
					</div>


				</div>

			</div>

			<!-- content end -->
		</div>

	</div>

	<?php
	include "footer.php";
	?>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"></script>

	<script language="javascript">
		function Validate()
		{
			if(document.chgPassword.oldPassword.value=="")
			{
				document.getElementById('errmsg').innerHTML='Please enter your Old Password!';
				document.chgPassword.oldPassword.focus();
				return false;
			}
			if(document.chgPassword.newPassword.value=="")
			{
				document.getElementById('errmsg').innerHTML='Please enter your New Password!';
				document.chgPassword.newPassword.focus();
				return false;
			}
			if(document.chgPassword.confirmPassword.value=="")
			{
				document.getElementById('errmsg').innerHTML='Please enter your Confirm Password!';
				document.chgPassword.confirmPassword.focus();
				return false;
			}
			if(document.chgPassword.newPassword.value!=document.chgPassword.confirmPassword.value)
			{
				document.chgPassword.newPassword.value="";
				document.chgPassword.confirmPassword.value="";
				document.getElementById('errmsg').innerHTML='New Password and  Confirm Password Fields do not match!';
				document.chgPassword.newPassword.focus();
				return false;
			}
		}
	</script>

</body>
</html>
