<?php
session_start();
include "inc/connection.php";
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
<?php include "head.php"; ?>
</head>
<body>

	<?php
	
	include "primary-menu.php";
	?> 
	<div class="container">
		<div class="welcome">
			<h1>Registration</h1>
		</div>
		<div class="ls_content">
		<!-- content start -->

		<!-- content end -->
	</div>

</div>

<?php
include "footer.php";
?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
