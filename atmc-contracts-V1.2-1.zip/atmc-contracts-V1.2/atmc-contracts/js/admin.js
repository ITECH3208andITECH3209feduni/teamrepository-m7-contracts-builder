jQuery( document ).ready(function() {


	/* STAFF START */

	/* delete admin staff start */
	jQuery( document ).on( "click", ".delete_staff", function() {

		var staff_id=jQuery(this).data("staffid");
		var result = confirm("Are you sure you want to delete?");
		if (result) {
			jQuery.ajax({
				type: "POST",
				url: "functions.php",
				data: {
					"action":"delete_staff",
					"staff_id":staff_id
				},
				success: function(response) {
					if(response=="1"){
						jQuery("#msg").html("Staff Deleted Successfully");
						jQuery(".tr"+staff_id).remove();
					}
				}
			});
		}
	});
	/* delete admin staff end */


	/* activate deactivate admin staff start */
	jQuery( document ).on( "click", ".change_staff_status", function() {

		var staff_id=jQuery(this).data("staffid");
		var staff_status=jQuery(this).data("status");

		jQuery.ajax({
			type: "POST",
			url: "functions.php",
			data: {
				"action":"change_staff_status",
				"staff_id":staff_id,
				"staff_status":staff_status
			},
			success: function(response) {
			}
		});

		if(staff_status=="deactivate"){
			jQuery(this).data("status", "activate");
			jQuery(this).attr("data-status", "activate");
			jQuery(this).addClass('btn-danger fa-close').removeClass('btn-success fa-check');
			jQuery("#msg").html("Staff Deactivated Successfully");

		}else{
			jQuery(this).data("status", "deactivate");
			jQuery(this).attr("data-status", "deactivate");
			jQuery(this).addClass('btn-success fa-check').removeClass('btn-danger fa-close');
			jQuery("#msg").html("Staff Activated Successfully");
		}

	});
	/* activate deactivate admin staff end */

	/* STAFF END */


	/* VACANCY START */

	/* delete admin vacancy start */
	jQuery( document ).on( "click", ".delete_vacancy", function() {

		var vacancy_id=jQuery(this).data("vacancyid");
		var result = confirm("Are you sure you want to delete?");
		if (result) {
			jQuery.ajax({
				type: "POST",
				url: "functions.php",
				data: {
					"action":"delete_vacancy",
					"vacancy_id":vacancy_id
				},
				success: function(response) {
					if(response=="1"){
						jQuery("#msg").html("Vacancy Deleted Successfully");
						jQuery(".tr"+vacancy_id).remove();
					}
				}
			});
		}
	});
	/* delete admin vacancy end */


	/* activate deactivate admin vacancy start */
	jQuery( document ).on( "click", ".change_vacancy_status", function() {

		var vacancy_id=jQuery(this).data("vacancyid");
		var vacancy_status=jQuery(this).data("status");

		jQuery.ajax({
			type: "POST",
			url: "functions.php",
			data: {
				"action":"change_vacancy_status",
				"vacancy_id":vacancy_id,
				"vacancy_status":vacancy_status
			},
			success: function(response) {
			}
		});

		if(vacancy_status=="deactivate"){
			jQuery(this).data("status", "activate");
			jQuery(this).attr("data-status", "activate");
			jQuery(this).addClass('btn-danger fa-close').removeClass('btn-success fa-check');
			jQuery("#msg").html("Vacancy Deactivated Successfully");

		}else{
			jQuery(this).data("status", "deactivate");
			jQuery(this).attr("data-status", "deactivate");
			jQuery(this).addClass('btn-success fa-check').removeClass('btn-danger fa-close');
			jQuery("#msg").html("Vacancy Activated Successfully");
		}

	});
	/* activate deactivate admin vacancy end */

	/* VACANCY END */


		/* POSITION START */

	/* delete admin position start */
	jQuery( document ).on( "click", ".delete_position", function() {

		var position_id=jQuery(this).data("positionid");
		var result = confirm("Are you sure you want to delete?");
		if (result) {
			jQuery.ajax({
				type: "POST",
				url: "functions.php",
				data: {
					"action":"delete_position",
					"position_id":position_id
				},
				success: function(response) {
					if(response=="1"){
						jQuery("#msg").html("Position Deleted Successfully");
						jQuery(".tr"+position_id).remove();
					}
				}
			});
		}
	});
	/* delete admin position end */


	/* activate deactivate admin position start */
	jQuery( document ).on( "click", ".change_position_status", function() {

		var position_id=jQuery(this).data("positionid");
		var position_status=jQuery(this).data("status");

		jQuery.ajax({
			type: "POST",
			url: "functions.php",
			data: {
				"action":"change_position_status",
				"position_id":position_id,
				"position_status":position_status
			},
			success: function(response) {
			}
		});

		if(position_status=="deactivate"){
			jQuery(this).data("status", "activate");
			jQuery(this).attr("data-status", "activate");
			jQuery(this).addClass('btn-danger fa-close').removeClass('btn-success fa-check');
			jQuery("#msg").html("Position Deactivated Successfully");

		}else{
			jQuery(this).data("status", "deactivate");
			jQuery(this).attr("data-status", "deactivate");
			jQuery(this).addClass('btn-success fa-check').removeClass('btn-danger fa-close');
			jQuery("#msg").html("Position Activated Successfully");
		}

	});
	/* activate deactivate admin position end */

	/* POSITION END */


	/* CONTRACT START */

	/* delete admin contract start */
	jQuery( document ).on( "click", ".delete_contract", function() {

		var contract_id=jQuery(this).data("contractid");
		var result = confirm("Are you sure you want to delete?");
		if (result) {
			jQuery.ajax({
				type: "POST",
				url: "functions.php",
				data: {
					"action":"delete_contract",
					"contract_id":contract_id
				},
				success: function(response) {
					if(response=="1"){
						jQuery("#msg").html("Contract Deleted Successfully");
						jQuery(".tr"+contract_id).remove();
					}
				}
			});
		}
	});
	/* delete admin contract end */


	/* activate deactivate admin contract start */
	jQuery( document ).on( "click", ".change_contract_status", function() {

		var contract_id=jQuery(this).data("contractid");
		var contract_status=jQuery(this).data("status");

		jQuery.ajax({
			type: "POST",
			url: "functions.php",
			data: {
				"action":"change_contract_status",
				"contract_id":contract_id,
				"contract_status":contract_status
			},
			success: function(response) {
			}
		});

		if(contract_status=="deactivate"){
			jQuery(this).data("status", "activate");
			jQuery(this).attr("data-status", "activate");
			jQuery(this).addClass('btn-danger fa-close').removeClass('btn-success fa-check');
			jQuery("#msg").html("Contract Deactivated Successfully");

		}else{
			jQuery(this).data("status", "deactivate");
			jQuery(this).attr("data-status", "deactivate");
			jQuery(this).addClass('btn-success fa-check').removeClass('btn-danger fa-close');
			jQuery("#msg").html("Contract Activated Successfully");
		}

	});
	/* activate deactivate admin contract end */

	/* CONTRACT END */


	/* APPLICATION START */

	/* delete application start */
	jQuery( document ).on( "click", ".delete_application", function() {

		var application_id=jQuery(this).data("applicationid");
		var result = confirm("Are you sure you want to delete?");
		if (result) {
			jQuery.ajax({
				type: "POST",
				url: "functions.php",
				data: {
					"action":"delete_application",
					"application_id":application_id
				},
				success: function(response) {
					if(response=="1"){
						jQuery("#msg").html("Application Deleted");
						jQuery(".tr"+application_id).remove();
					}
				}
			});
		}
	});
	/* delete application end */


	/* shotlist application start */
	jQuery( document ).on( "click", ".shortlist_applicaton", function() {

		var application_id=jQuery(this).data("applicationid");
		var application_status=jQuery(this).data("status");

		jQuery.ajax({
			type: "POST",
			url: "functions.php",
			data: {
				"action":"shortlist_applicaton",
				"application_id":application_id,
				"application_status":application_status
			},
			success: function(response) {
			}
		});

		if(application_status=="deactivate"){
			jQuery(this).data("status", "activate");
			jQuery(this).attr("data-status", "activate");
			jQuery(this).addClass('btn-danger fa-close').removeClass('btn-success fa-check');
			jQuery("#msg").html("Application Rejected");

		}else{
			jQuery(this).data("status", "deactivate");
			jQuery(this).attr("data-status", "deactivate");
			jQuery(this).addClass('btn-success fa-check').removeClass('btn-danger fa-close');
			jQuery("#msg").html("Application Shortlisted");
		}

	});
	/* shotlist application end */

	/* approve application start */
	jQuery( document ).on( "click", ".approved_application", function() {

		var application_id=jQuery(this).data("applicationid");
		var application_status=jQuery(this).data("status");

		jQuery.ajax({
			type: "POST",
			url: "functions.php",
			data: {
				"action":"approved_application",
				"application_id":application_id,
				"application_status":application_status
			},
			success: function(response) {
			}
		});

		if(application_status=="deactivate"){
			jQuery(this).data("status", "activate");
			jQuery(this).attr("data-status", "activate");
			jQuery(this).addClass('btn-danger fa-close').removeClass('btn-success fa-check');
			jQuery("#msg").html("Application Disapproved");

		}else{
			jQuery(this).data("status", "deactivate");
			jQuery(this).attr("data-status", "deactivate");
			jQuery(this).addClass('btn-success fa-check').removeClass('btn-danger fa-close');
			jQuery("#msg").html("Application Approved");
		}

	});
	/* approve application end */

	/* APPLICATION END */


});