<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
header("Location: sign-in.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
</head>
<body>

	<?php
	include "primary-menu.php";

	$button_name="Import Now";
	$form_title="Import Staffs";
	$button_value="importdata";

	$_GET['positionid']="";



	if(isset($_POST['importdata']))
	{

		$import_file = $_FILES['import_file']['tmp_name'];
		$handle = fopen($import_file, "r");
		$c = 0;
		while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
		{

			$position = (isset($filesop[0]) && !empty($filesop[0]) ? $filesop[0] : NULL);
			$fullname = (isset($filesop[1]) && !empty($filesop[1]) ? $filesop[1] : NULL);
			$email = (isset($filesop[2]) && !empty($filesop[2]) ? $filesop[2] : NULL);
			$address = (isset($filesop[3]) && !empty($filesop[3]) ? $filesop[3] : NULL);
			$entitle = (isset($filesop[4]) && !empty($filesop[4]) ? $filesop[4] : NULL);

			$checkrow=mysqli_fetch_array(mysqli_query($con,"select staff_id from staffs where email='".$email."'"));
			if(count($checkrow)==0){
				$sql = " INSERT INTO staffs (position_id, fullname, email, address, entitle, status) values('".$position."', '".$fullname."', '".$email."' , '".$address."', '".$entitle."', '0') ";
				mysqli_query($con,$sql) or die(mysqli_error($con));
			}
			$c = $c + 1;
		}

		$_SESSION['have_error']="Data Imported Successfully.";
		header('Location: staffs-list.php');
		exit();

	}


	?> 
	<div class="container-fluid">
		<div class="ls_content">
			<!-- content start -->

			<div class="row">

				<div class="col-md-8 col-md-offset-2">

					<div class="ls_over_to_you ls_sign_in text-center">
						<h1><?php echo $form_title; ?></h1>
						<div class="registration_form">
							<div>
								<p>Upload a .csv file</p>
							</div>

							<form  class="adminform" name="importFileForm" id="addform" onSubmit="return validate_import_form();" action="" method="post" enctype="multipart/form-data" autocomplete="off">
							<div id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;"> </div>

								<div class="form-group">
									<label>File <small>(Upload a .csv file format)</small></label>
									<input class="form-control" type="file" name="import_file" id="import_file" value="" >
								</div>

									<button type="submit" class="btn btn-default front_button"  name="<?php echo $button_value; ?>" id="<?php echo $button_value; ?>" value="<?php echo $button_value; ?>"><?php echo $button_name; ?></button>

						</form>

						</div>
					</div>


				</div>

			</div>

			<!-- content end -->
		</div>

	</div>

	<?php
	include "footer.php";
	?>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"></script>

	<script type="text/javascript">

		function validate_import_form()
		{

			t = importFileForm.import_file.value.trim();
			if( t == ""){
				document.getElementById('errmsg').innerHTML='Please select a .csv file to import data.';
				importFileForm.import_file.focus();
				return (false);
			}
			return true;
		}

	</script>

</body>
</html>
