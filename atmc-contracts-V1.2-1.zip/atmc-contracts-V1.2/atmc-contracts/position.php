<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
header("Location: sign-in.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
</head>
<body>

	<?php
	include "primary-menu.php";


	if( (isset($_GET['positionid']) && $_GET['action']=='edit') )
	{


		$sql1="select * from positions where position_id='".$_GET['positionid']."' ";
		$result1=mysqli_query($con,$sql1);
		$row1=mysqli_fetch_array($result1);

		$position=mysqli_real_escape_string($con,$row1['position']);

		$button_value="updateposition";

		$button_name="Update Position";
		$form_title="Edit Position";

	}else{

		$button_name="Add Position";
		$form_title="Add Position";
		$button_value="addposition";

		$_GET['positionid']="";

	}

	if(isset($_POST['addposition']))
	{

//
		$checkrow=mysqli_fetch_array(mysqli_query($con,"select position from positions where position='".$_POST['position']."'"));
		if(count($checkrow) > 0)
		{
			$_SESSION['have_error']="Position already exists.";
			header('Location: position-list.php');
			exit();
		}
//

		$position=mysqli_real_escape_string($con,$_POST['position']);

		$sql ="INSERT INTO positions (position) values('".$position."')";

		mysqli_query($con,$sql) or die(mysqli_error($con));
		$cid = mysqli_insert_id();
		$_SESSION['have_error']="Position Added Successfully.";
		header('Location: position-list.php');
		exit();
	}

	if(isset($_POST['updateposition']))
	{
		$positionid = mysqli_real_escape_string($con,$_POST['positionid']);
		$position=mysqli_real_escape_string($con,$_POST['position']);

//
		$checkrow=mysqli_fetch_array(mysqli_query($con,"select position from positions where position='".$position."' AND position_id!='".$positionid."' "));
		if(count($checkrow) > 0)
		{
			$_SESSION['have_error']="Position already exists.";
			header('Location: position-list.php');
			exit();
		}
//

		$sql = "UPDATE positions SET position='$position' WHERE position_id='$positionid'";
		mysqli_query($con,$sql);

		$_SESSION['have_error']="Position Updated Successfully.";
		header('Location: position-list.php');

		exit();
	}


	?> 
	<div class="container">
		<div class="ls_content">
			<!-- content start -->

			<div class="row">

				<div class="col-md-8 col-md-offset-2">

					<div class="ls_over_to_you ls_sign_in text-center">
						<h1><?php echo $form_title; ?></h1>
						<div class="registration_form">
							<div>
								<p>Enter Details Below</p>
							</div>

							<form name="addPositionForm" action="" onSubmit="return validate_position();" method="post" enctype="multipart/form-data" autocomplete="off">
								<span id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;">
									<?php 
									if(isset($_SESSION['have_error']))
									{
										echo $_SESSION['have_error'];
										unset($_SESSION['have_error']);
									}
									?>
								</span>

								<?php if( isset($_GET['positionid']) && $_GET['positionid']!=null ) 
								{
									?>
									<input type="hidden" name="positionid" value="<?php echo $_GET['positionid']; ?>">
									<?php
								}
								?>
								<div class="form-group">
									<label for="position">Position:</label>
									<input type="text" class="form-control" name="position" id="position" placeholder="Position" value="<?php echo $position; ?>">
								</div>
								<button type="submit" class="btn btn-default front_button" name="<?php echo $button_value; ?>"><?php echo $button_name; ?></button>
							</form>

						</div>
					</div>


				</div>

			</div>

			<!-- content end -->
		</div>

	</div>

	<?php
	include "footer.php";
	?>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"></script>

	<script type="text/javascript">

		function validate_position()
		{

			t = addPositionForm.position.value.trim();
			if( t == ""){
				document.getElementById('errmsg').innerHTML='Enter Position.';
				addPositionForm.position.focus();
				return (false);
			}
			return true;
		}

	</script>

</body>
</html>
