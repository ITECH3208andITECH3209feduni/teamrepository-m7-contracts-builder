<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
header("Location: sign-in.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
	<link rel="stylesheet" type="text/css" href="css/pagination_css.css">
	<link rel="stylesheet" type="text/css" href="admin/css/colorbox.css">
</head>
<body>

	<?php

	include "primary-menu.php";
	?> 
	<div class="container">
		<div class="ls_content">
			<!-- content start -->
			<div class="col-md-12">

				<div class="ls_powerful_soft text-center">
					<h1>Contract List</h1>
				</div>


				<div class="msg-div" style="color:#FF0000;margin-top:0px;padding:5px;text-align: center;">
					<span  id="msg">
						<?php 
						if(isset($_SESSION['have_error']))
						{
							echo $_SESSION['have_error'];
							unset($_SESSION['have_error']);
						}
						?>
					</span>
				</div>

				<div class="table-responsive">
					<table class="table table-bordered table-hover">
						<thead>
							<tr>
								<th class="text-center">Sr.No</th>
								<th class="text-center">Title</th>
								<th class="text-center">PDF</th>
								<th class="text-center">Status</th>
								<th class="text-center">Edit</th>
								<th class="text-center">Delete</th>
							</tr>
						</thead>
						<tbody>

							<?php
							$tbl_name="contracts";
							$adjacents = 1;

							$query="SELECT COUNT(*) as num FROM  $tbl_name order by contract_id  desc "; 

							$total_pages = mysqli_fetch_array(mysqli_query($con,$query));
							$total_pages = $total_pages[num];
							$targetpage = "contract-list.php";
							$limit =20;
							$page = $_GET['page'];
							$limitvalue = $page * $limit - ($limit);  
							if($page) 
								$start = ($page - 1) * $limit;
							else
								$start = 0;
							$limitvalue = $page * $limit - ($limit);  

							$sql="SELECT * FROM  $tbl_name order by contract_id  desc LIMIT $start, $limit ";

							$result = mysqli_query($con,$sql);
							if ($page == 0) $page = 1;
							$prev = $page - 1;
							$next = $page + 1;	
							$lastpage = ceil($total_pages/$limit);
							$lpm1 = $lastpage - 1;
							$pagination = "";
							if($lastpage > 1)
							{	
								$pagination .= "<div class=\"pagination\">";
								if ($page > 1) 
									$pagination.= "<a href=\"$targetpage?page=$prev\">«</a>";
								else
									$pagination.= "<span class=\"disabled\">«</span>";	
								if ($lastpage < 7 + ($adjacents * 2))
								{	
									for ($counter = 1; $counter <= $lastpage; $counter++)
									{
										if ($counter == $page)
											$pagination.= "<span class=\"current\">$counter</span>";
										else
											$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
									}
								}
								elseif($lastpage > 5 + ($adjacents * 2))
								{
									if($page < 1 + ($adjacents * 2))		
									{
										for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
										{
											if ($counter == $page)
												$pagination.= "<span class=\"current\">$counter</span>";
											else
												$pagination.= "<a href=\"$targetpage?page=$counter \">$counter</a>";					
										}
										$pagination.= "<span style='color:#23B7E5'>...</span>";
										$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
										$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
									}
									elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
									{
										$pagination.= "<a href=\"$targetpage?page=1\">1</a>";
										$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
										$pagination.= "<span style='color:#23B7E5'>...</span>";
										for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
										{
											if ($counter == $page)
												$pagination.= "<span class=\"current\">$counter</span>";
											else
												$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
										}
										$pagination.= "<span style='color:#23B7E5'>...</span>";
										$pagination.= "<a href=\"$targetpage?page=$lpm1\">$lpm1</a>";
										$pagination.= "<a href=\"$targetpage?page=$lastpage\">$lastpage</a>";		
									}
									else
									{
										$pagination.= "<a href=\"$targetpage?page=1 \">1</a>";
										$pagination.= "<a href=\"$targetpage?page=2\">2</a>";
										$pagination.= "<span style='color:#23B7E5'>...</span>";
										for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
										{
											if ($counter == $page)
												$pagination.= "<span class=\"current\">$counter</span>";
											else
												$pagination.= "<a href=\"$targetpage?page=$counter\">$counter</a>";					
										}
									}
								}
								if ($page < $counter - 1) 
									$pagination.= "<a href=\"$targetpage?page=$next \">»</a>";
								else
									$pagination.= "<span class=\"disabled\">»</span>";
								$pagination.= "</div>\n";		
							}
							?>
							<?php
							$count = isset($_GET['page']) && $_GET['page'] > 1 ? $limitvalue : 0; 
							$num=mysqli_num_rows($result);
							if($num>0)
							{
								while($row = mysqli_fetch_array($result))
								{
									$count++; 
									?>
									<tr class="text-center tr<?php echo $row['contract_id']; ?>">
										<td style="width:1%;"><?php echo $count; ?></td>
										<td><?php echo $row['title']; ?></td>
										<td><?php echo (isset($row['pdf']) && !empty($row['pdf'])) ? $row['pdf'] : "Not Generated"; ?></td>
										<td style="width:1%;"><span id="like-panel-<?php echo $row['contract_id']; ?>">
											<?php
											if($row['status']=='1')
											{
												?>
												<a href="javascript: void(0)" data-contractid="<?php echo $row['contract_id']; ?>" data-status="deactivate" class="change_contract_status btn btn-success fa fa-check bigger-130" style="padding:4px 8px;"></a>
												<?php
											}
											else{
												?>
												<a href="javascript: void(0)" data-contractid="<?php echo $row['contract_id']; ?>" data-status="activate" class="change_contract_status btn btn-danger fa fa-close bigger-130" style="padding:4px 8px;"></a>
												<?php
											}
											?>
										</span> </td>

										<td style="width:1%;"><a href="contract.php?contractid=<?php echo $row['contract_id']; ?>&action=edit" class="btn btn-primary fa fa-pencil bigger-130 "  title="Edit" style="padding:4px 8px;"></a></td>

										<td style="width:1%;"><a href="javascript: void(0)" data-contractid="<?php echo $row['contract_id']; ?>" class="delete_contract btn btn-danger fa fa-trash bigger-130" id="<?php echo $row['contract_id']; ?>" style="padding:4px 8px;"></a> </td>
									</tr>
									<?php
								}}else
								{ ?>
									<td style="padding:4px; text-align:center;" colspan="20" align="center"><b style="font-size:18px;color:#FF0000;">No Data Available!</b></td>
									<?php
								}
								?>
							</tbody>
						</table>
					</div>
					<div class="pagi" style="float:right;contract:relative;">
						<?php echo $pagination; ?>
					</div>


				</div>

				<!-- content end -->
			</div>

		</div>

		<?php
		include "footer.php";
		?>
		<script type="text/javascript" src="admin/js/show-colorbox.js"></script>
		<script src="admin/js/jquery.colorbox.js"></script>
		<script>
			var $n = jQuery.noConflict();

			$n(document).ready(function(){
			});

			$n(document).ready(function(){
//Examples of how to assign the Colorbox event to elements
$n(".group1").colorbox({rel:'group1'});
$n(".group2").colorbox({rel:'group2', transition:"fade"});
$n(".group3").colorbox({rel:'group3', transition:"none", width:"80%", height:"80%"});
$n(".group4").colorbox({rel:'group4', slideshow:false});
$n(".ajax").colorbox();
$n(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
$n(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
$n(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
$n(".inline").colorbox({inline:true, width:"50%"});
$n(".callbacks").colorbox({
	onOpen:function(){ alert('onOpen: colorbox is about to open'); },
	onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
	onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
	onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
	onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
});

$n('.non-retina').colorbox({rel:'group5', transition:'none'})
$n('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});

//Example of preserving a JavaScript event for inline calls.
$n("#click").click(function(){ 
	$n('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
	return false;
});
});
</script>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
<script src="js/admin.js"></script>
</body>
</html>
