<?php
session_start();
include "inc/connection.php";
$loc = "index.php";
session_destroy();
header('Location: '.$loc);
?>