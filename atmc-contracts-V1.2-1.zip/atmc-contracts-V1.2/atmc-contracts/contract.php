<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
	header("Location: sign-in.php");
}
/*if(isset($_POST['content']) && !empty($_POST['content'])){
require('html2pdf.php');
$aaaa = str_replace('</p>', '</p><br>', $_POST['content']);
$aaaa = str_replace('&nbsp;', '', $aaaa);
$aaaa = str_replace(' <p>', '<p>', $aaaa);

$pdf=new PDF_HTML();
$pdf->SetFont('Arial','',12);
$pdf->AddPage();
$pdf->WriteHTML($aaaa);
$filename="pdf/".time().".pdf";
$pdf->Output($filename,'F');
}*/
?>

<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
	
	<style type="text/css">
		.tox-notifications-container{
			display: none !important;
			visibility: hidden !important;
		}
	</style>
</head>
<body>

	<?php
	include "primary-menu.php";


	if( (isset($_GET['contractid']) && $_GET['action']=='edit') )
	{

		$sql1="select * from contracts where contract_id='".$_GET['contractid']."' ";
		$result1=mysqli_query($con,$sql1);
		$row1=mysqli_fetch_array($result1);

		$title=mysqli_real_escape_string($con,$row1['title']);
		$content=mysqli_real_escape_string($con,$row1['content']);

		$button_value="updatecontract";

		$button_name="Update Contract";
		$form_title="Edit Contract";

	}else{

		$title="";
		$content="";

		$button_name="Add Contract";
		$form_title="Add Contract";
		$button_value="addcontract";

		$_GET['contractid']="";

	}

	if(isset($_POST['addcontract']))
	{
		$title=mysqli_real_escape_string($con,$_POST['title']);
		$content=mysqli_real_escape_string($con,$_POST['content']);
		$sql ="INSERT INTO contracts (title, content) values('".$title."', '".$content."')";
		mysqli_query($con,$sql) or die(mysqli_error($con));
		$_SESSION['have_error']="Contract Added Successfully.";
		header('Location: contract-list.php');
		exit();
	}

	if(isset($_POST['updatecontract']))
	{

		$contractid = mysqli_real_escape_string($con,$_POST['contractid']);
		$title=mysqli_real_escape_string($con,$_POST['title']);
		$content=mysqli_real_escape_string($con,$_POST['content']);

		$sql = "UPDATE contracts SET title='$title', content='$content' WHERE contract_id='$contractid'";
		mysqli_query($con,$sql);

		$_SESSION['have_error']="Contract Updated Successfully.";
		header('Location: contract-list.php');
		exit();
	}


	?> 
	<div class="container">
		<div class="ls_content">
			<!-- content start -->

			<div class="row">

				<div class="col-md-12">

					<div class="ls_over_to_you ls_sign_in text-center" style="width: 100%;">
						<h1><?php echo $form_title; ?></h1>
						<div class="registration_form">
							<div>
								<p>Enter Details Below</p>
							</div>

							<form name="addContractForm" action="" onSubmit="return validate_contract();" method="post" enctype="multipart/form-data" autocomplete="off">
								<span id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;">
									<?php 
									if(isset($_SESSION['have_error']))
									{
										echo $_SESSION['have_error'];
										unset($_SESSION['have_error']);
									}
									?>
								</span>

								<?php if( isset($_GET['contractid']) && $_GET['contractid']!=null ) 
								{
									?>
									<input type="hidden" name="contractid" value="<?php echo $_GET['contractid']; ?>">
									<?php
								}
								?>
								<div class="form-group">
									<label for="title">Title:</label>
									<input type="text" class="form-control" name="title" id="title" placeholder="Contract" value="<?php echo $title; ?>">
									<div class="form-group">
										<textarea class="form-control" rows="40" name="content" id="content"><?php echo $content; ?></textarea>
									</div>
								</div>
								<button type="submit" class="btn btn-default front_button" name="<?php echo $button_value; ?>"><?php echo $button_name; ?></button>
							</form>

						</div>
					</div>


				</div>

			</div>

			<!-- content end -->
		</div>

	</div>

	<?php
	include "footer.php";
	?>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"></script>

	<script type="text/javascript">

		function validate_contract()
		{

			t = addContractForm.title.value.trim();
			if( t == ""){
				document.getElementById('errmsg').innerHTML='Enter Contract Title.';
				addContractForm.title.focus();
				return (false);
			}

/*t = addContractForm.content.value.trim();
if( t == ""){
document.getElementById('errmsg').innerHTML='Enter Contract Content';
addContractForm.content.focus();
return (false);
}*/
return true;
}

</script>

<script src="js/tinymce.min.js"></script>
	<script>tinymce.init({selector:'textarea'});</script>

</body>
</html>
