<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( isset($_SESSION['admin_id']) )
{
header("Location: vacancies-applied.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<?php include "head.php"; ?>
</head>
<body>

<?php
include "primary-menu.php";
?> 
<div class="container">
	<div class="ls_content">

<!-- content start -->

<div class="row">

<div class="col-md-8 col-md-offset-2">

<div class="ls_over_to_you ls_sign_in text-center">
<h1>Forgot Password</h1>
<div class="registration_form">

<div>
<p>Enter valid registered Email ID to receive password reset link.</p>
</div>

<form name="cForgotPasswordForm" action="check-login-candidate.php" onSubmit="return validate_forgot();" method="post" enctype="multipart/form-data" autocomplete="off">
<span id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;">
<?php 
if(isset($_SESSION['have_error']))
{
echo $_SESSION['have_error'];
unset($_SESSION['have_error']);
}
?>
</span>
<div class="form-group">
<label for="email">Email ID:</label>
<input type="text" class="form-control" name="email" id="email" placeholder="Email ID" value="<?php echo $cookie_email; ?>">
</div>
<button type="submit" class="btn btn-default front_button" name="forgotpassword">Submit</button>
</form>

</div>
</div>

</div>

</div>

<!-- content end -->
</div>

</div>

<?php
include "footer.php";
?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>


<script type="text/javascript">

function validate_forgot()
{

t = cForgotPasswordForm.email.value.trim();
if( t == ""){
document.getElementById('errmsg').innerHTML='Enter Email ID.';
cForgotPasswordForm.email.focus();
return (false);
}
t = cForgotPasswordForm.email.value.trim();
emailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
if (!t.match(emailformat)) 
{
document.getElementById('errmsg').innerHTML='Enter a valid Email ID.';
cForgotPasswordForm.email.focus();
return false;
}
return true;

}	

</script>
</body>
</html>
