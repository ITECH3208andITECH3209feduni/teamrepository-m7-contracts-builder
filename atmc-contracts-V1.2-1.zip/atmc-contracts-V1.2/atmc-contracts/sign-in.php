<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( isset($_SESSION['admin_id']) )
{
header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
</head>
<body>

	<?php
$cookie_email="";
$cookie_password="";
$remember_me="";
	if( isset($_COOKIE['cEmail']) && !empty($_COOKIE['cEmail']) && isset($_COOKIE['cPassword']) && !empty($_COOKIE['cPassword']) ) {
		$cookie_email = $_COOKIE['cEmail'];
		$cookie_password = $_COOKIE['cPassword'];
		$remember_me=1;
	}

	include "primary-menu.php";
	?> 
	<div class="container">
<div class="ls_content">
<!-- content start -->

<div class="row">

	<div class="col-md-8 col-md-offset-2">

		<div class="ls_over_to_you ls_sign_in text-center">
			<h1>Sign in</h1>
			<div class="registration_form">
				<div>
					<p>Enter the details below to sing in.</p>
				</div>

				<form name="cSigninForm" action="check-login.php" onSubmit="return validate_sign_in();" method="post" enctype="multipart/form-data" autocomplete="off">
					<span id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;">
						<?php 
						if(isset($_SESSION['have_error']))
						{
							echo $_SESSION['have_error'];
							unset($_SESSION['have_error']);
						}
						?>
					</span>
					<div class="form-group">
						<label for="email">Email address:</label>
						<input type="text" class="form-control" name="email" id="email" placeholder="Email ID" value="<?php echo $cookie_email; ?>">
					</div>
					<div class="form-group">
						<label for="pwd">Password: <span class="pull-right"><a href="forgot-password.php">Forgot Password?</a></span></label>
						<input type="password" class="form-control" name="password" id="pwd" placeholder="Password" value="<?php echo $cookie_password; ?>">
					</div>
					<div class="checkbox">
						<label><input type="checkbox" name="remember_me" <?php echo (isset($remember_me) && !empty($remember_me) ? "checked" : ""); ?>> Remember me</label>
					</div>
					<button type="submit" class="btn btn-default front_button">Sign in</button>
				</form>

			</div>
		</div>


	</div>

</div>

<!-- content end -->
</div>

</div>

<?php
include "footer.php";
?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>


<script type="text/javascript">

function validate_sign_in()
{

	t = cSigninForm.email.value.trim();
	if( t == ""){
		document.getElementById('errmsg').innerHTML='Enter Username or Email ID.';
		cSigninForm.email.focus();
		return (false);
	}

/*	t = cSigninForm.email.value.trim();
	emailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
	if (!t.match(emailformat)) 
	{
		document.getElementById('errmsg').innerHTML='Enter a valid Email ID.';
		cSigninForm.email.focus();
		return false;
	}*/

	t = cSigninForm.password.value.trim();
	if( t == ""){
		document.getElementById('errmsg').innerHTML='Enter Your Password.';
		cSigninForm.password.focus();
		return (false);
	}

	return true;

}	

</script>
</body>
</html>
