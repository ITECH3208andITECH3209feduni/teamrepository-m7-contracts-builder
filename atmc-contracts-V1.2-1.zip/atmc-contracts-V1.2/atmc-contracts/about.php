<?php
session_start();
include "inc/connection.php";
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
<?php include "head.php"; ?>
</head>
<body>

	<?php
	
	include "primary-menu.php";
	?> 
	<div class="container">
		<div class="ls_content">

		<!-- content start -->

		<div class="row ls_about_us">
			
			<div class="col-md-12">

				<div class="col-md-8 col-md-offset-2">

					<div class="ls_over_to_you ls_about text-center ls_white_txt">
					<h1 class="ls_white_txt">Why Employment Portal?</h1>
					<p>We're passionate about connecting people to great careers. Our powerful platform helps you optimise every step of the talent management lifecycle so that everyone can reach their full potential.</p>
					<a href="sign-up.php" style="width: auto;" class="front_button">Get Started</a>
					</div>

					<div class="ls_over_to_you ls_about text-center">
					<h1>What we do</h1>
					<p>Employment Portal is the talent management platform HR practitioners, people leaders, employees and candidates love to use</p>
					<a href="sign-up.php" style="width: auto;" class="front_button">Get Started</a>
					</div>


			</div>


			</div>

		

		</div>

		<!-- content end -->
	</div>

</div>

<?php
include "footer.php";
?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
