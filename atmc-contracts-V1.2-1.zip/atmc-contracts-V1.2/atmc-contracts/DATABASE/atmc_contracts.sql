-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 09, 2020 at 01:33 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atmc_contracts`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `smtpemail` varchar(150) DEFAULT NULL,
  `password` text NOT NULL,
  `role_id` int(11) NOT NULL COMMENT '1=HR Manager, 2=Manager, 3=Candidate, 4=Admin',
  `profile_pic` varchar(255) NOT NULL,
  `unique_id` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`member_id`, `fullname`, `email`, `smtpemail`, `password`, `role_id`, `profile_pic`, `unique_id`, `status`) VALUES
(1, 'admin', 'admin@admin.com', 'admin@smtp.com', '21232f297a57a5a743894a0e4a801fc3', 4, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
CREATE TABLE IF NOT EXISTS `applications` (
  `application_id` int(11) NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `form_data` text NOT NULL,
  `cv` varchar(255) DEFAULT NULL,
  `cover_letter` varchar(255) DEFAULT NULL,
  `is_shortlisted` int(11) NOT NULL DEFAULT '0' COMMENT '1=shortlisted, 0=not shotlisted',
  `shortlisted_by` int(11) DEFAULT NULL,
  `is_approved` int(11) NOT NULL DEFAULT '0' COMMENT '1=approved, 0=unapproved',
  `approved_by` int(11) DEFAULT NULL,
  `date_applied` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_approved` datetime DEFAULT NULL,
  PRIMARY KEY (`application_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`application_id`, `vacancy_id`, `member_id`, `candidate_id`, `form_id`, `form_data`, `cv`, `cover_letter`, `is_shortlisted`, `shortlisted_by`, `is_approved`, `approved_by`, `date_applied`, `date_approved`) VALUES
(1, 1, 1, 5, 1, '[{\"title\":\"First Name\",\"value\":\"Hemendra\"},{\"title\":\"Last Name\",\"value\":\"Yadav\"},{\"title\":\"Gender\",\"value\":\"Male\"},{\"title\":\"Country\",\"value\":\"India\"},{\"title\":\"Skills\",\"value\":[\"HTML\",\"CSS\",\"JS\",\"PHP\"]}]', 'uploads/cv/woocommerce-placeholder-400x400.png', 'uploads/cover_letter/Pirate Face = large front central.png', 0, 1, 0, NULL, '2020-09-25 18:16:15', NULL),
(3, 3, 2, 5, 3, '[{\"title\":\"Fullname\",\"value\":\"asdfasdf\"}]', NULL, NULL, 0, 2, 0, NULL, '2020-09-26 14:12:07', NULL),
(4, 2, 1, 5, 4, '[{\"title\":\"Fullname\",\"value\":\"Bob\"},{\"title\":\"Age\",\"value\":\"30\"},{\"title\":\"Hobbies\",\"value\":[\"Games\",\"Painting\"]},{\"title\":\"Gender\",\"value\":\"Male\"}]', 'uploads/cv/R9csOQ.png', 'uploads/cover_letter/1601966480Pirate Face = large front central.png', 0, NULL, 0, NULL, '2020-10-06 12:11:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
CREATE TABLE IF NOT EXISTS `contracts` (
  `contract_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text,
  `pdf` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`contract_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contracts`
--

INSERT INTO `contracts` (`contract_id`, `title`, `content`, `pdf`, `status`) VALUES
(1, 'testadf', '<p>asdfsdftest</p>', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
CREATE TABLE IF NOT EXISTS `positions` (
  `position_id` int(11) NOT NULL AUTO_INCREMENT,
  `position` varchar(150) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`position_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`position_id`, `position`, `status`) VALUES
(3, 'HR Manager', 1),
(2, 'Manager', 1),
(4, 'Assosiate', 1),
(5, 'Analyst', 1),
(13, 'asdfasdf', 1),
(14, 'adsfasdf', 1);

-- --------------------------------------------------------

--
-- Table structure for table `staffs`
--

DROP TABLE IF EXISTS `staffs`;
CREATE TABLE IF NOT EXISTS `staffs` (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT,
  `position_id` int(11) DEFAULT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text,
  `entitle` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffs`
--

INSERT INTO `staffs` (`staff_id`, `position_id`, `fullname`, `email`, `address`, `entitle`, `status`) VALUES
(2, 4, 'james', 'james@test.com', NULL, NULL, 1),
(3, 5, 'will', 'will@test.com', NULL, NULL, 1),
(4, 4, 'lily', 'lily@test.com', NULL, NULL, 1),
(5, 3, 'bob', 'bob@test.com', NULL, NULL, 1),
(6, 2, 'test', 'test@test.com', '635 CANDLEWOOD TRL', 'pro', 1),
(19, 2, 'test2', 'abc2@test.com', '102 NY', 'manager2', 1),
(20, 3, 'test3', 'abc3@test.com', '103 NY', 'manager3', 1),
(21, 4, 'test4', 'abc4@test.com', '104 NY', 'manager4', 1),
(22, 5, 'test5', 'abc5@test.com', '105 NY', 'manager5', 1),
(28, 4, 'abc111', 'abc111@test.com', 'abc111 address', 'abc1111 en', 1),
(29, 1, 'test1', 'abc1@test.com', '101 NY', 'manager1', 0),
(30, 6, 'test6', 'abc6@test.com', '106 NY', 'manager6', 0),
(31, 7, 'test7', 'abc7@test.com', '107 NY', 'manager7', 1),
(32, 8, 'test8', 'abc8@test.com', '108 NY', 'manager8', 0),
(33, 9, 'test9', 'abc9@test.com', '109 NY', 'manager9', 1),
(34, 10, 'test10', 'abc10@test.com', '110 NY', 'manager10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vacancies`
--

DROP TABLE IF EXISTS `vacancies`;
CREATE TABLE IF NOT EXISTS `vacancies` (
  `vacancy_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `vacancy_category_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `min_salary` varchar(150) DEFAULT NULL,
  `max_salary` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`vacancy_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vacancies`
--

INSERT INTO `vacancies` (`vacancy_id`, `member_id`, `vacancy_category_id`, `title`, `description`, `min_salary`, `max_salary`, `status`) VALUES
(1, 1, 4, 'Backend developer', 'Backend developer job available. Backend developer job available. Backend developer job available. Backend developer job available. Backend developer job available. Backend developer job available. Backend developer job available. ', '15000', 20000, 1),
(2, 1, 5, 'Frontend Developer', 'Frontend Developer available. Frontend Developer available. Frontend Developer available. Frontend Developer available. Frontend Developer available. Frontend Developer available. Frontend Developer available. Frontend Developer available. Frontend Developer available. ', '10000', 20000, 1),
(3, 2, 2, 'wordpress', 'wordpress developer required. wordpress developer required. wordpress developer required. wordpress developer required. wordpress developer required. wordpress developer required. ', '25000', 35000, 1),
(6, 3, 0, 'Wordpress Developer', 'this is a wordpress developer vacancy', NULL, NULL, 1),
(8, 1, 2, 'php required', 'html,css,js,php etc.', '10000', 15000, 1),
(9, 1, 5, 'Graphic Designer', 'Graphic Designer Needed', '15000', 25000, 1),
(10, 2, 2, 'adf', 'sadf', '30000', 40000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vacancies_forms`
--

DROP TABLE IF EXISTS `vacancies_forms`;
CREATE TABLE IF NOT EXISTS `vacancies_forms` (
  `form_id` int(11) NOT NULL AUTO_INCREMENT,
  `vacancy_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `form_data` text,
  `cv` int(11) DEFAULT NULL,
  `cover_letter` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vacancies_forms`
--

INSERT INTO `vacancies_forms` (`form_id`, `vacancy_id`, `member_id`, `title`, `form_data`, `cv`, `cover_letter`, `status`) VALUES
(1, 1, 1, 'PHP Developer Form', '[{\"title\":\"First Name\",\"type\":\"text\"},{\"title\":\"Last Name\",\"type\":\"text\"},{\"title\":\"Gender\",\"type\":\"radiobutton\",\"options\":[\"Male\",\"Female\"]},{\"title\":\"Country\",\"type\":\"select\",\"options\":[\"India\",\"USA\",\"UAE\",\"Russia\"]},{\"title\":\"Skills\",\"type\":\"checkbox\",\"options\":[\"HTML\",\"CSS\",\"JS\",\"PHP\"]}]', 1, 1, 0),
(2, 8, 1, 'PHP Developer Required', '[{\"title\":\"Full Name\",\"type\":\"text\"},{\"title\":\"Age\",\"type\":\"text\"},{\"title\":\"Address\",\"type\":\"textarea\"},{\"title\":\"Country\",\"type\":\"select\",\"options\":[\"India\",\"USA\",\"UAE\"]},{\"title\":\"Hobbies\",\"type\":\"checkbox\",\"options\":[\"Movies\",\"Reading\"]},{\"title\":\"Gender\",\"type\":\"radiobutton\",\"options\":[\"Male\",\"Female\",\"Other\"]}]', 1, 1, 0),
(3, 3, 2, 'test1 form', '[{\"title\":\"Fullname\",\"type\":\"text\"}]', 0, 0, 0),
(4, 2, 1, 'Frontend Developer', '[{\"title\":\"Fullname\",\"type\":\"text\"},{\"title\":\"Age\",\"type\":\"text\"},{\"title\":\"Hobbies\",\"type\":\"checkbox\",\"options\":[\"Games\",\"Painting\",\"Singing\"]},{\"title\":\"Gender\",\"type\":\"radiobutton\",\"options\":[\"Male\",\"Female\"]}]', 1, 1, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
