<!---//start-footer---->
<div class="ftr-nav">
	<!-- <div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6 col-xs-6">
				<p class="text-left copyright">  Employment Portal &copy; Copyright </p>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-6">
				<div class="ls_social_footer">
					<ul>
						<li><a href="#" class="fa fa-facebook social-round-icon"></i></a></li>
						<li><a href="#"><i class="fa fa-instagram social-round-icon"></i></a></li>
						<li><a href="#"><i class="fa fa-pinterest-p social-round-icon"></i></a></li>
						<li><a href="#"><i class="fa fa-youtube social-round-icon"></i></a></li>
					</ul>
				</div>
			</div>
		</div> -->
<div class="container">
   <div id="footer">
      <style type="text/css">
         #footer p { margin-bottom: 0px; }
         #footer .f-panel { float: left; margin-right: 10px; }
         #footer .panel-contents { padding: 14px; background-color: #fff; text-align: center; min-height: 50px; }
      </style>
      <div id="footer-wrapper">
         <div id="footer-top">
            <div class="f-panel" style="width: 250px">
               <div class="title">
                  University Partners						
               </div>
               <div class="panel-contents">
                  <p><a href="/universities" target="_blank">Click here to view our University Partners</a></p>
               </div>
            </div>
            <div class="f-panel" style="width: 235px">
               <div class="title">
                  ATMC Mobile App 						
               </div>
               <div class="panel-contents">
                  <p><a title="iOS" href="https://itunes.apple.com/us/app/atmc/id1293164683?ls=1&amp;mt=8"><img src="images/aaple.png" alt="" width="102" height="47"></a><a title="Android" href="https://play.google.com/store/apps/details?id=com.ebabu.atmc"><img src="images/android.png" alt="" width="102" height="47"></a></p>
               </div>
            </div>
            <div class="f-panel" style="width: ">
               <div class="title">
                  Pathway Programme						
               </div>
               <div class="panel-contents">
                  <p style="text-align: center;"><a href="http://www.aupp.education" target="_blank"><img src="images/aupp-logo2.jpg" alt="AUPP"></a></p>
               </div>
            </div>
            <div class="f-panel" style="width: 360px; margin-right: 0">
               <div class="title">
                  Links						
               </div>
               <div class="panel-contents">
                  <p><a href="http://www.vic.gov.au/" target="_blank"> <img title="Victoria - The place to be" src="images/vic-logo.jpg" alt="Victoria"></a>&nbsp; &nbsp; &nbsp;<a href="http://www.studyinaustralia.gov.au/" target="_blank"><img title="Australia - Future Unlimited" src="images/fu-logo.jpg" alt="Australia"></a>&nbsp; &nbsp; &nbsp;<a href="http://www.immi.gov.au/students/studying-in-australia.htm" target="_blank"><img title="Study In Australia" src="images/study-logo.jpg" alt="Study In Australia"></a></p>
               </div>
            </div>
         </div>
         <div id="footer-mid">
            <div class="col">
               <div class="title">About</div>
               <a href="/about/about-atmc">About ATMC</a><br><a href="/about/message-from-the-ceo">Message from the CEO</a><br>					
            </div>
            <div class="col">
               <div class="title">Courses</div>
               <a href="/courses/federation-university-australia">Federation University Australia</a><br><a href="/courses/university-of-the-sunshine-coast">University of the Sunshine Coast</a><br><a href="/courses/pathway-programs">Pathway Programs</a><br>					
            </div>
            <div class="col">
               <div class="title">Students</div>
               <a href="/student-support/before-you-arrive">Before You Arrive</a><br><a href="/student-support/career-development">Career Development</a><br><a href="/student-support/accommodation">Accommodation</a><br><a href="/student-support/library">Library</a><br><a href="/student-support/assessments-exam-results">Assessments &amp; Exam Results</a><br><a href="/student-support/english-language">English Language</a><br><a href="/student-support/support-services">Services</a><br><a href="/student-support/teaching-learning">Teaching &amp; Learning</a><br><a href="/student-support/academic-support">Academic Support</a><br><a href="/student-support/enrolment-timetables-2020">Enrolment &amp; Timetables 2020</a><br>					
            </div>
            <div class="col">
               <div class="title">Australia</div>
               <a href="/australia/before-you-leave">Before you Leave</a><br><a href="/australia/accommodation">Accommodation</a><br><a href="/australia/getting-around">Getting Around</a><br><a href="/australia/departure-arrival">Departure &amp; Arrival</a><br><a href="/australia/living-expenses">Living Expenses</a><br><a href="/australia/social-activities">Social Activities</a><br><a href="/australia/money">Money</a><br><a href="/australia/health-wellbeing">Health &amp; Wellbeing</a><br><a href="/australia/living-in-australia">Living in Australia</a><br><a href="/australia/working-in-australia">Working in Australia</a><br><a href="/australia/study-in-australia">Studying in Australia</a><br><a href="/australia/returning-home">Returning Home</a><br><a href="/australia/useful-links">Useful Links</a><br><a href="/australia/insurance">Insurance</a><br><a href="/australia/coronavirus-covid-19-update">Coronavirus COVID-19 update</a><br><a href="/australia/coronavirus-faq">Coronavirus FAQ</a><br>					
            </div>
            <div class="col">
               <div class="title">Apply</div>
               <a href="/resources/how-to-apply">How to Apply</a><br><a href="/resources/brochures-prospectuses">Brochures &amp; Prospectus</a><br><a href="/resources/academic-calendar">Academic Calendar</a><br><a href="/resources/policies-procedures">Policies &amp; Procedures</a><br>					
            </div>
            <div class="col">
               <div class="title">Campuses</div>
               <a href="/campuses/melbourne">Melbourne</a><br><a href="/campuses/sydney">Sydney</a><br>					
            </div>
            <div class="col last">
               <div style="font-size: 12px; padding-bottom: 5px;">
                  Join Our Mailing List
               </div>
               <form action="/+cms/php/components/cms_forms/process_form.php" method="post" id="emailForm" style="font-size: 10px;margin-top:5px;" data-gtm-vis-first-on-screen-30110580_15="266223" data-gtm-vis-total-visible-time-30110580_15="100" data-gtm-vis-has-fired-30110580_15="1">
                  <input type="hidden" name="formID" value="1">
                  <input type="text" placeholder="Firstname" name="firstname" style="border:0; padding:3px;  width:170px;"><br>
                  <input type="text" placeholder="Lastname" name="lastname" style="border:0; padding:3px; margin-top: 5px; width:170px"><br>
                  <input type="text" placeholder="Email" name="email" style="border:0; padding:3px; margin-top: 5px; width:170px;"><br>
                  <input type="submit" class="button" style="margin-top:5px;" value="submit" name="submit">
               </form>
               <div style="padding-top: 20px;display: inline-flex;"><a href="https://twitter.com/ATMC_australia" target="_blank" style="margin-right: 10px;"><img src="images/2.png" alt="Twitter" width="40" height="40"></a><a href="https://www.facebook.com/ATMCSOCIAL/" target="_blank" style="margin-right: 10px;"><img src="images/3.png" alt="Facebook" width="40" height="40"></a><a href="https://www.instagram.com/atmc.social/" target="_blank" style="margin-right: 10px;"><img src="images/37.png" alt="Instagram" width="40" height="40"></a></div>
            </div>
         </div>
         <div id="footer-bottom">
            <div class="right text-right" style="color: #666;">Website by <a href="http://www.whiterhino.com.au" target="_blank">WhiteRhino</a></div>
            <a href="/" target="_self">Home</a> • 
            <a href="/copyright-notice" target="_self">Copyright Notice</a> • 
            <a href="/disclamers" target="_self">Disclaimers</a> • 
            <a href="/terms-conditions" target="_self">Terms &amp; Conditions</a> • 
            <a href="/privacy-policy" target="_self">Privacy Policy</a>					
            <div style="color: #666;">© Copyright 2019. Australian Technical and Management College Pty Ltd. as trustee for Australian Technical and Management College Trust trading as Australian Technical and Management College. All rights reserved. This website constitutes an approved ATMC Notice Board&nbsp;ATMC ABN: 73 130 044 745, ATMC RTO No. 22158, ATMC CRICOS Provider No. 03013D, Federation University Australia CRICOS Provider No. 00103D, University of the Sunshine Coast CRICOS Provider No 01595D						
            </div>
         </div>
      </div>
   </div>
</div>



	</div>
<!---//end-footer---->