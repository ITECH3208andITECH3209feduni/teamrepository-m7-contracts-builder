<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
if($email == false){
  header('Location: login-user.php');
}
$fetch_data = "SELECT * FROM usertable WHERE email = '$email'";
$run_query = mysqli_query($con, $fetch_data);
$fetch_info = mysqli_fetch_assoc($run_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $fetch_info['name'] ?> Home</title>
   <style>
   
*{
    margin: 0;
    padding: 0;
}
body{
    font-family: 'Lato', sans-serif;
}
.wrapper{
    width: 1370px;
    margin: auto;
}
header{
    background: linear-gradient(rgba(0,0,0,0.75),rgba(0,0,0,0.75)),url(images/background.png);
    height: 100vh;
    -webkit-background-size: cover;
    background-size: cover;
    background-position: center center;
    position: relative;
}
.nav-area{
    float: right;
    list-style: none;
    margin-top: 30px;
}
.nav-area li{
    display: inline-block;
}
.nav-area li a {
color: #fff;
text-decoration: none;
padding: 5px 20px;
font-family: poppins;
font-size: 16px;
text-transform: uppercase;

}
.nav-area li a:hover{
    background: #fff;
    color: #333;
}
.logo{
    float: left;
	left:-10px;
}
.logo img{
    width: 60%;
	padding: 15px 0;
	background: linear-gradient(to left, #333, #333 50%, #eee 75%, #333 75%);
	left:-10px;
    }
.welcome-text{
    position: absolute;
    width: 600px;
    height: 300px;
    margin: 20% 30%;
    text-align: center;
}
button a{
	display: inline-block;
     color: #red;
text-decoration: none;
padding: 5px 20px;
font-family: poppins;
font-size: 16px;
text-transform: uppercase;
    }
    button a:hover{
         background: #fff;
    color: #333;
    }
.welcome-text h1{
    text-align: center;
    color: #fff;
    text-transform: uppercase;
    font-size: 60px;
}
.welcome-text a{
    border: 1px solid #fff;
    padding: 10px 25px;
    text-decoration: none;
    text-transform: uppercase;
    font-size: 14px;
    margin-top: 20px;
    display: inline-block;
    color: #fff;
}
.welcome-text a:hover{
    background: #fff;
    color: #333;
}

/*resposive*/

@media (max-width:600px){
    .wrapper {
width: 100%;
}
.logo {
float: none;
left:0px;
width: 50%;
text-align: center;
margin: auto;
}
img {
	left:0px;
width: ;
}
.nav-area {
float: none;
margin-top: 0;
}
    .nav-area li a {
padding: 5px;
font-size: 11px;
}
.nav-area {
text-align: center;
}
    .welcome-text {
width: 100%;
height: auto;
margin: 30% 0;
}
    .welcome-text h1 {
font-size: 30px;
}
}
</style>

<link rel="stylesheet" href="style.css"></head>

<body>
<header>
    <div class="wrapper">
        <div class="logo">
            <img src="images/logo.png" alt="">
        </div>
<ul class="nav-area">
<li><a href="home.php">Home</a></li>
<li><a href="error.html">Staff Details</a></li>
<li><a href="error.html">View Reports</a></li>
<li><a href="#">Search</a></li>
<button type="button" class="btn btn-light"><a href="logout-user.php">Logout</a></button>
</ul>
</div>
<div class="welcome-text">
        <h1>
Contracts Builder</h1>
<a href="#">Prepare Contract</a>
    </div>
</header>
</body>
</html>