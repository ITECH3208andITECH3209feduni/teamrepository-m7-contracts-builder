<?php
session_start();
include "inc/connection.php";
error_reporting(0);

$position_count=mysqli_num_rows(mysqli_query($con,"SELECT * FROM positions"));
$staff_count=mysqli_num_rows(mysqli_query($con,"SELECT * FROM staffs"));
$contract_count=mysqli_num_rows(mysqli_query($con,"SELECT * FROM contracts"));

$conRes= mysqli_query($con,"SELECT contracts.contract_id,contracts.title, sent_contracts.is_signed, COUNT(sent_contracts.is_signed) AS count FROM Contracts
	INNER JOIN sent_contracts ON sent_contracts.contract_id=contracts.contract_id WHERE sent_contracts.is_signed IS NOT NULL GROUP BY sent_contracts.is_signed, sent_contracts.contract_id");
$conTitle=array();
$ns = array();

while ($conRow=mysqli_fetch_array($conRes)) {
	array_push($conTitle, $conRow['title']);
	if($conRow['is_signed']==1 && $conRow['count']==1){
		$ns[$conRow['contract_id']][1] = $conRow['count'];
	}else{
		if($conRow['is_signed']==1){
				$ns[$conRow['contract_id']][1] = $conRow['count'];
		}else{
			$ns[$conRow['contract_id']][0] = $conRow['count'];
		}
	}
}

//print_r($ns);

$conNotSigned= array();
$conSigned= array();
foreach ($ns as $key => $value) {
	if(!empty($ns[$key][0])){
		array_push($conNotSigned, $ns[$key][0]);
	}else{
		array_push($conNotSigned, 0);
	}

	if(!empty($ns[$key][1])){
		array_push($conSigned, $ns[$key][1]);
	}else{
		array_push($conSigned, 0);
	}
}
$conSigned = implode(",",$conSigned);
$conNotSigned = implode(",",$conNotSigned);
$conTitle = implode("','",array_unique($conTitle));
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
</head>
<body>

	<?php

	include "primary-menu.php";
	?> 
	<div class="container">
		<div class="ls_content">
			<!-- content start -->

			<div class="row" style="margin-bottom: 40px;">

				<div class="ls_over_to_you ls_sign_in text-center">
					<h1>Reports and Charts</h1>

					<div class="col-md-4">
						<div class="panel panel-dark-green">
							<div class="panel-heading">
								<div class="row">
									<div class="col-xs-3"> <i class="fa fa-list fa-5x"></i> </div>
									<div class="col-xs-9 text-right">
										<div class="huge"><?php echo (isset($position_count) ? $position_count : 0) ?></div>
										<div>Positions</div>
									</div>
								</div>
							</div>
							<a href="./position-list.php">
								<div class="panel-footer"> <span class="pull-left">View All</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
									<div class="clearfix"></div>
								</div>
							</a>
						</div>
					</div>

					<div class="col-md-4">
						<div class="panel panel-dark-blue">
							<div class="panel-heading">
								<div class="row">
									<div class="col-xs-3"> <i class="fa fa-users fa-5x"></i> </div>
									<div class="col-xs-9 text-right">
										<div class="huge"><?php echo (isset($staff_count) ? $staff_count : 0) ?></div>
										<div>Staffs</div>
									</div>
								</div>
							</div>
							<a href="./staffs-list.php">
								<div class="panel-footer"> <span class="pull-left">View All</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
									<div class="clearfix"></div>
								</div>
							</a>
						</div>
					</div>

					<div class="col-md-4">
						<div class="panel panel-dark-orange">
							<div class="panel-heading">
								<div class="row">
									<div class="col-xs-3"> <i class="fa fa-list-alt fa-5x"></i> </div>
									<div class="col-xs-9 text-right">
										<div class="huge"><?php echo (isset($contract_count) ? $contract_count : 0) ?></div>
										<div>Contracts</div>
									</div>
								</div>
							</div>
							<a href="./contract-list.php">
								<div class="panel-footer"> <span class="pull-left">View All</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
									<div class="clearfix"></div>
								</div>
							</a>
						</div>
					</div>

				</div>

			</div>

			<div class="row">

				<div class="ls_over_to_you ls_sign_in text-center">
					<!-- 				<h1>Reports and Charts</h1> -->

					<canvas id="bar-chart-grouped" width="800" height="450"></canvas>
				</div>

			</div>

			<!-- content end -->
		</div>

	</div>

	<?php
	include "footer.php";
	?>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"></script>
	<script src="js/Chart.min.js"></script>
	<script type="text/javascript">
		new Chart(document.getElementById("bar-chart-grouped"), {
			type: 'bar',
			data: {
				labels: [<?php echo "'".$conTitle."'"; ?>],
				datasets: [
				{
					label: "Signed",
					backgroundColor: "#3e95cd",
					data: [<?php echo $conSigned; ?>,100]
				}, {
					label: "Not Signed",
					backgroundColor: "#8e5ea2",
					data: [<?php echo $conNotSigned; ?>,100]
				}
				]
			},
			options: {
				title: {
					display: true,
					text: 'Contracts signed status'
				}
			}
		});
	</script>
</body>
</html>
