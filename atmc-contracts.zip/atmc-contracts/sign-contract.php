<?php
session_start();
include "inc/connection.php";

error_reporting(0);
/*if( isset($_SESSION['admin_id']) )
{
header("Location: index.php");
}*/
$msg="";
if(isset($_GET['key']) && $_GET['action']=='sign-contract' ) 
{
$canQuery="SELECT * FROM sent_contracts where unique_id='".md5($_GET['key'])."' ";
$canRes=mysqli_query($con,$canQuery);
$canRow=mysqli_fetch_array($canRes);
}else{
header('Location: sign-in.php');
}


if(isset($_POST['signaturesubmit'])){ 
	require_once('PHPMailer/PHPMailerAutoload.php');
require('html2pdf.php');
	$signature = $_POST['signature'];
	$signatureFileName = uniqid().'.png';
	$signature = str_replace('data:image/png;base64,', '', $signature);
	$signature = str_replace(' ', '+', $signature);
	$data = base64_decode($signature);
	$file = 'images/signatures/'.$signatureFileName;
	file_put_contents($file, $data);



$pdfsql="select * from contracts where contract_id='".$canRow['contract_id']."' ";
$pdfresult=mysqli_query($con,$pdfsql);
$pdfrow=mysqli_fetch_array($pdfresult);
$pcontent=stripslashes($pdfrow['content']);
$attached_sign=stripslashes($pdfrow['attached_sign']);

$stqry=" SELECT * FROM staffs WHERE staff_id=".$canRow['staff_id'];
$stres=mysqli_query($con, $stqry);
$strow = mysqli_fetch_array($stres);

$receiverEmail = $strow['email'];
$getqry=" SELECT smtpemail FROM admin WHERE role_id=4 ";
$getres=mysqli_query($con, $getqry);
$getrow=mysqli_fetch_array($getres);
$senderEmail =	$getrow['smtpemail'];
//$senderEmail =	'hemendray@lexcis.com';

$pdfContent = "";
$pdfContent .= $pcontent;

if(isset($_SERVER['HTTPS'])){
$protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
}
else{
$protocol = 'http';
}
$my_site_url = $protocol."://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/';

//echo $my_site_url.'/'.$file;exit;

$htmlData = str_replace('</p>', '</p>', $pdfContent);
$htmlData = str_replace('&nbsp;', '', $htmlData);
$htmlData = str_replace('{{Name}}', $strow['fullname'], $htmlData);
$htmlData = str_replace('{{Full Name}}', $strow['fullname'], $htmlData);
$htmlData = str_replace('{{Email}}', $strow['email'], $htmlData);
$htmlData = str_replace('{{CurrentDate}}', date("Y-m-d"), $htmlData);
//$htmlData = str_replace('&lt;&lt;Signature&gt;&gt;', '<img src='.$my_site_url.$file.'>', $htmlData);
if(!empty($attached_sign)){
					$path =  BASEPATH.$attached_sign;
					$htmlData = str_replace('{{AttachedSign}}', '<img width="100" src="'.$path.'" />', $htmlData);
}

if(!empty($file)){
					$staff_sign_path =  BASEPATH.$file;
					$htmlData = str_replace('{{StaffSign}}', '<img width="100" src="'.$staff_sign_path.'" />', $htmlData);
}

$pdf=new PDF_HTML();
$pdf->SetMargins(10,35,10);
$pdf->SetAutoPageBreak(auto,30);
$pdf->SetFont('Arial','',12);
$pdf->AddPage();
$pdf->WriteHTML($htmlData);
$filename="sent-pdf/".$receiverEmail.".pdf";
//$pdf-> Image($file,10,200,35,35);
$pdf->Output($filename,'F');
//$pdf->Output();

$to = $receiverEmail;
$subject = "Contract Signed";
$message = "<p><b>".$strow['fullname']."</b> has signed the contract.</p>";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From : ".$senderEmail."";
//$mail = new PHPMailer(true);
//$mail->AddAttachment($filename, $receiverEmail.'.pdf');
mail($to, $subject, $message, $headers);


mysqli_query($con, " UPDATE sent_contracts SET is_signed='1', sign='$file' WHERE unique_id='".md5($_GET['key'])."' ");


	$msg = "<div class='alert alert-success'>Signature Uploaded</div>";
} 

?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
	<style>
		#canvasDiv{
			position: relative;
			border: 2px dashed grey;
			height:300px;
		}
		#toolbar{
			display: none !important;
		}
	</style>
</head>
<body>

	<?php
	include "primary-menu.php";



?> 
<div class="container">
	<div class="ls_content">
		<!-- content start -->

		<div class="row">

			<div class="col-md-10 col-md-offset-1">

				<div class="ls_over_to_you ls_sign_in text-center">
					<h1>Sign Contract</h1>
					<div class="registration_form">
						<div>
							<p></p>
						</div>
						<embed src="sent-pdf/<?php echo $canRow['email']; ?>.pdf" type="application/pdf" width="100%" height="600px" />
					</div>
				</div>


			</div>

		</div>
		<?php if( isset($canRow) && $canRow['is_signed']==0 && $msg=="" ){ ?>
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<br>
					<?php echo isset($msg)?$msg:''; ?>
					<h2>Do your digital signature in the dotted box below.</h2>
					<hr>
					<div id="canvasDiv"></div>
					<br>
					<button type="button" class="btn btn-danger front_button" id="reset-btn">Clear</button>
					<button type="button" class="btn btn-success front_button" id="btn-save">Send</button>
				</div>
				<form id="signatureform" action="" style="display:none" method="post">
					<input type="hidden" id="signature" name="signature">
					<input type="hidden" name="signaturesubmit" value="1">
				</form>
			</div>
		</div>
	<?php } ?>

		<!-- content end -->
	</div>

</div>

<?php
include "footer.php";
?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
<script>
	$(document).ready(() => {
		var canvasDiv = document.getElementById('canvasDiv');
		var canvas = document.createElement('canvas');
		canvas.setAttribute('id', 'canvas');
		canvasDiv.appendChild(canvas);
		$("#canvas").attr('height', $("#canvasDiv").outerHeight());
		$("#canvas").attr('width', $("#canvasDiv").width());
		if (typeof G_vmlCanvasManager != 'undefined') {
			canvas = G_vmlCanvasManager.initElement(canvas);
		}

		context = canvas.getContext("2d");
		$('#canvas').mousedown(function(e) {
			var offset = $(this).offset()
			var mouseX = e.pageX - this.offsetLeft;
			var mouseY = e.pageY - this.offsetTop;

			paint = true;
			addClick(e.pageX - offset.left, e.pageY - offset.top);
			redraw();
		});

		$('#canvas').mousemove(function(e) {
			if (paint) {
				var offset = $(this).offset()
//addClick(e.pageX - this.offsetLeft, e.pageY - this.offsetTop, true);
addClick(e.pageX - offset.left, e.pageY - offset.top, true);
console.log(e.pageX, offset.left, e.pageY, offset.top);
redraw();
}
});

		$('#canvas').mouseup(function(e) {
			paint = false;
		});

		$('#canvas').mouseleave(function(e) {
			paint = false;
		});

		var clickX = new Array();
		var clickY = new Array();
		var clickDrag = new Array();
		var paint;

		function addClick(x, y, dragging) {
			clickX.push(x);
			clickY.push(y);
			clickDrag.push(dragging);
		}

		$("#reset-btn").click(function() {
			context.clearRect(0, 0, window.innerWidth, window.innerWidth);
			clickX = [];
			clickY = [];
			clickDrag = [];
		});

		$(document).on('click', '#btn-save', function() {
			var mycanvas = document.getElementById('canvas');
			var img = mycanvas.toDataURL("image/png");
			anchor = $("#signature");
			anchor.val(img);
			$("#signatureform").submit();
		});

		var drawing = false;
		var mousePos = {
			x: 0,
			y: 0
		};
		var lastPos = mousePos;

		canvas.addEventListener("touchstart", function(e) {
			mousePos = getTouchPos(canvas, e);
			var touch = e.touches[0];
			var mouseEvent = new MouseEvent("mousedown", {
				clientX: touch.clientX,
				clientY: touch.clientY
			});
			canvas.dispatchEvent(mouseEvent);
		}, false);


		canvas.addEventListener("touchend", function(e) {
			var mouseEvent = new MouseEvent("mouseup", {});
			canvas.dispatchEvent(mouseEvent);
		}, false);


		canvas.addEventListener("touchmove", function(e) {

			var touch = e.touches[0];
			var offset = $('#canvas').offset();
			var mouseEvent = new MouseEvent("mousemove", {
				clientX: touch.clientX,
				clientY: touch.clientY
			});
			canvas.dispatchEvent(mouseEvent);
		}, false);



// Get the position of a touch relative to the canvas
function getTouchPos(canvasDiv, touchEvent) {
	var rect = canvasDiv.getBoundingClientRect();
	return {
		x: touchEvent.touches[0].clientX - rect.left,
		y: touchEvent.touches[0].clientY - rect.top
	};
}


var elem = document.getElementById("canvas");

var defaultPrevent = function(e) {
	e.preventDefault();
}
elem.addEventListener("touchstart", defaultPrevent);
elem.addEventListener("touchmove", defaultPrevent);


function redraw() {
//
lastPos = mousePos;
for (var i = 0; i < clickX.length; i++) {
	context.beginPath();
	if (clickDrag[i] && i) {
		context.moveTo(clickX[i - 1], clickY[i - 1]);
	} else {
		context.moveTo(clickX[i] - 1, clickY[i]);
	}
	context.lineTo(clickX[i], clickY[i]);
	context.closePath();
	context.stroke();
}
}
})

</script>
<script>
$(document).ready(function(){
 $("#toolbar").hide();
});
</script>

</body>
</html>
