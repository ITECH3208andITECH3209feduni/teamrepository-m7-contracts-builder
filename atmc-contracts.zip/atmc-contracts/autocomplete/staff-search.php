<?php
include "../inc/connection.php";
$q=mysqli_real_escape_string($con,trim($_GET['q']));
if($q=="%")
{
exit();
}
$my_data=mysqli_real_escape_string($con,$q);
$sql="SELECT DISTINCT fullname FROM staffs WHERE fullname LIKE '%$my_data%'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));
if($result)
{
while($row=mysqli_fetch_array($result))
{	
echo $row['fullname']."\n";
}
}
?>
