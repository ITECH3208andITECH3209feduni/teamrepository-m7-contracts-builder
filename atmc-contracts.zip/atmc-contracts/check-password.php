<?php 
session_start();
include "inc/connection.php";
/*if($_SESSION['admin_name']=="")
{
header('Location: index.php');
}*/
$login=mysqli_real_escape_string($con,$_SESSION['admin_email']);
$OldPasswrd=trim($_POST["oldPassword"]);
$OldPasswrd1=md5($OldPasswrd);
$NewPassword=trim($_POST["newPassword"]);
$NewPassword1=md5($NewPassword);  

$query="select * from admin where email='".$login."'";
$result=mysqli_query($con,$query);
$myrow=mysqli_fetch_array($result);		
$trow=mysqli_num_rows($result);
if ($trow!=0) {
	$query1="select * from admin where email='".$login."' and password='".$OldPasswrd1."'";
	$result1=mysqli_query($con,$query1);
	$myrow1=mysqli_fetch_array($result1);		
	$trow1=mysqli_num_rows($result1);
	if ($trow1!=0) {

		$query3="update admin set password='".$NewPassword1."' where
		email='".$login."' and password='".$OldPasswrd1."'";
		$result3=mysqli_query($con,$query3);

		header("Location: chng-password.php?er=3");
	} else {
		header("Location: chng-password.php?er=2");
	}
} else {
	header("Location: chng-password.php?er=1");
}
?>