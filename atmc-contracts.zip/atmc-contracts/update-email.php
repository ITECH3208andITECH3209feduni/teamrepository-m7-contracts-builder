<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
header("Location: sign-in.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
</head>
<body>

	<?php
	include "primary-menu.php";



	if(isset($_POST['updateemail']))
	{
		$eemail=mysqli_real_escape_string($con,$_POST['email']);
		$smtpemail=mysqli_real_escape_string($con,$_POST['smtpemail']);
		if(!empty($eemail)){
			$sql = "UPDATE admin SET email='$eemail' WHERE member_id='".$_SESSION['admin_id']."'";
			mysqli_query($con,$sql);
		}

		if(!empty($smtpemail)){
			$sql = "UPDATE admin SET smtpemail='$smtpemail' WHERE member_id='".$_SESSION['admin_id']."'";
			mysqli_query($con,$sql);
		}

		$_SESSION['have_error']="Email Updated Successfully.";

	}

		$sql1="select * from admin where member_id='".$_SESSION['admin_id']."' ";
	$result1=mysqli_query($con,$sql1);
	$row1=mysqli_fetch_array($result1);
	$email=mysqli_real_escape_string($con,$row1['email']);
	$smtpemail=mysqli_real_escape_string($con,$row1['smtpemail']);
	$button_value="updateemail";
	$button_name="Update";
	$form_title="Update Email";

	?> 
	<div class="container">
		<div class="ls_content">
			<!-- content start -->

			<div class="row">

				<div class="col-md-8 col-md-offset-2">

					<div class="ls_over_to_you ls_sign_in text-center">
						<h1><?php echo $form_title; ?></h1>
						<div class="registration_form">
							<div>
								<p>Enter Details Below</p>
							</div>

							<form  class="adminform" name="addMemberform" id="addform" onSubmit="return csv_validate();" action="" method="post" enctype="multipart/form-data" autocomplete="off">
								<span id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;">
						<?php 
						if(isset($_SESSION['have_error']))
						{
							echo $_SESSION['have_error'];
							unset($_SESSION['have_error']);
						}
						?>
					</span>

								<div class="form-group">
									<label>Email ID</label>
									<input class="form-control" type="text" placeholder="Email ID" name="email" id="email" value="<?php echo $email; ?>" maxlength="100">
								</div>

								<div class="form-group">
									<label>SMTP Email ID</label>
									<input class="form-control" type="text" placeholder="SMTP Email ID" name="smtpemail" id="smtpemail" value="<?php echo $smtpemail; ?>" maxlength="100">
								</div>


								<button type="submit" class="btn btn-default front_button"  name="<?php echo $button_value; ?>" id="<?php echo $button_value; ?>" value="<?php echo $button_value; ?>"><?php echo $button_name; ?></button>

							</form>

						</div>
					</div>


				</div>

			</div>

			<!-- content end -->
		</div>

	</div>

	<?php
	include "footer.php";
	?>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"></script>

</body>
</html>
