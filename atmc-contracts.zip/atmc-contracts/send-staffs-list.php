<?php
session_start();
include "inc/connection.php";

error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
	header("Location: sign-in.php");
}

$contract = isset($_GET['contract']) && !empty($_GET['contract']) ? $_GET['contract'] : "";
if(isset($contract) && !empty($contract)){
	$pdfsql="select * from contracts where contract_id='".$contract."' ";
	$pdfresult=mysqli_query($con,$pdfsql);
	$pdfrow=mysqli_fetch_array($pdfresult);
	$pcontent=stripslashes($pdfrow['content']);
	$attached_sign=stripslashes($pdfrow['attached_sign']);
	//print_r(BASEPATH.$attached_sign);
//print_r($pcontent);exit;

	if( isset($_POST['send-contract']) && count($_POST['selected_staff']) > 0 ){
		require_once('PHPMailer/PHPMailerAutoload.php');
		require('html2pdf.php');
		$status = isset($_GET['status']) && !empty($_GET['status']) ? $_GET['status'] : "";

		$staffIdArray = implode(",",$_POST['selected_staff']);;

		$stqry=" SELECT * FROM staffs WHERE staff_id IN (".$staffIdArray.") ";
		$stres=mysqli_query($con, $stqry);
		while($strow = mysqli_fetch_array($stres)){

			$receiverEmail = $strow['email'];
			$getqry=" SELECT smtpemail FROM admin WHERE role_id=4 ";
			$getres=mysqli_query($con, $getqry);
			$getrow=mysqli_fetch_array($getres);
			$senderEmail =	$getrow['smtpemail'];
//$senderEmail =	'hemendray@lexcis.com';

			$pdfContent = "";
//$pdfContent .= "<h2>".$strow['fullname']."</h2>";
			$pdfContent .= $pcontent;
//$pdfContent .= "<hr><p>Staff Signature</p>";


			$htmlData = str_replace('</p>', '</p>', $pdfContent);
			$htmlData = str_replace('&nbsp;', '', $htmlData);
			$htmlData = str_replace('{{Name}}', $strow['fullname'], $htmlData);
			$htmlData = str_replace('{{Full Name}}', $strow['fullname'], $htmlData);
			$htmlData = str_replace('{{Email}}', $strow['email'], $htmlData);
			$htmlData = str_replace('{{CurrentDate}}', date("Y-m-d"), $htmlData);
			if(!empty($attached_sign)){
					$path =  BASEPATH.$attached_sign;
					$htmlData = str_replace('{{AttachedSign}}', '<img width="100" src="'.$path.'" />', $htmlData);
				}

			$pdf=new PDF_HTML();
			$pdf->SetMargins(10,35,10);
			$pdf->SetAutoPageBreak(auto,30);
			$pdf->SetFont('Arial','',12);
			$pdf->AddPage();
			$pdf->WriteHTML($htmlData);
			$filename="sent-pdf/".$receiverEmail.".pdf";
			$pdf->Output($filename,'F');
//$pdf->Output();
//exit;

			$randomNumber = rand();
			$unique_id = md5($randomNumber);

			if(isset($_SERVER['HTTPS'])){
				$protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
			}
			else{
				$protocol = 'http';
			}
			$my_site_url = $protocol."://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/';
			$resetURL = $my_site_url."sign-contract.php?key=".$randomNumber."&action=sign-contract";

			$to = $receiverEmail;
			$subject = "Contract for Sign";
			$message = "<h3>Hello ".$strow['fullname'].",</h3>
			<p>Please click the below link to reset your password:<br>
			<a href='".$resetURL."' target='_blank'>".$resetURL."</a>
			</p>";

			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= "From : ".$senderEmail."";
			$mail = new PHPMailer(true);
			$mail->AddAttachment($filename, $receiverEmail.'.pdf');

			if( mail($to, $subject, $message, $headers) ){

				if(isset($status) && $status==0){
					/*change status of active cotract*/
					mysqli_query($con, " UPDATE sent_contracts SET active_contract=0 WHERE staff_id='".$strow['staff_id']."' ");

					mysqli_query($con, " INSERT INTO sent_contracts (contract_id, staff_id, fullname, email, contract_pdf, unique_id, is_signed,active_contract, sent_status) values('".$contract."', '".$strow['staff_id']."', '".$strow['fullname']."', '".$strow['email']."', '".$filename."', '".$unique_id."', '0', '1', '1') ");
					mysqli_query($con, " UPDATE staffs SET sent_status='1' WHERE staff_id='".$strow['staff_id']."' ");


				}elseif(isset($status) && ( $status==1 || $status==2 ) ){
					mysqli_query($con, " UPDATE sent_contracts SET contract_id='".$contract."', is_signed='0', sent_status='1', contract_pdf='".$filename."', unique_id='".$unique_id."' WHERE staff_id='".$strow['staff_id']."' and contract_id=$contract");
				}

			}else{

				if(isset($status) && $status==0){
					/*change status of active cotract*/
					mysqli_query($con, " UPDATE sent_contracts SET active_contract=0 WHERE staff_id='".$strow['staff_id']."' ");
					
//mysqli_query($con, " INSERT INTO sent_contracts (contract_id, staff_id, fullname, email, sent_status) values('".$contract."', '".$strow['staff_id']."', '".$strow['fullname']."', '".$strow['email']."', '2') ");
					mysqli_query($con, " INSERT INTO sent_contracts (contract_id, staff_id, fullname, email, contract_pdf, unique_id, is_signed,active_contract, sent_status) values('".$contract."', '".$strow['staff_id']."', '".$strow['fullname']."', '".$strow['email']."', '".$filename."', '".$unique_id."', '0', '1', '1') ");
					mysqli_query($con, " UPDATE staffs SET sent_status='1' WHERE staff_id='".$strow['staff_id']."' ");
				}elseif(isset($status) && ( $status==1 || $status==2 ) ){
//mysqli_query($con, " UPDATE sent_contracts SET contract_pdf = NULL, unique_id = NULL, is_signed = NULL, sent_status='2' WHERE staff_id='".$strow['staff_id']."' ");
					mysqli_query($con, " UPDATE sent_contracts SET contract_id='".$contract."', is_signed='0', sent_status='1', contract_pdf='".$filename."', unique_id='".$unique_id."' WHERE staff_id='".$strow['staff_id']."'  and contract_id=$contract");
				}

			}

		}
//exit;
		$_SESSION['have_error']="Contract Sent Completed.<br>";
		echo $resetURL;

	}

}

?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
	<link rel="stylesheet" type="text/css" href="css/pagination_css.css">
	<link rel="stylesheet" type="text/css" href="css/colorbox.css">
</head>
<body>

	<?php
	include "primary-menu.php";
	?> 
	<div class="container">
		<div class="ls_content">
			<!-- content start -->
			<div class="col-md-12">

				<div class="ls_powerful_soft text-center">
					<h1>Contract Name: <?php echo $pdfrow['title']; ?></h1>
				</div>


				<div class="msg-div" style="color:#FF0000;margin-top:0px;padding:5px;text-align: center;">
					<span  id="msg">
						<?php 
						if(isset($_SESSION['have_error']))
						{
							echo $_SESSION['have_error'];
							unset($_SESSION['have_error']);
						}
						?>
					</span>
				</div>

				<div class="table-responsive">
					<form name="sendContractForm" action="" onSubmit="return validate_send_contract();" method="post" enctype="multipart/form-data" autocomplete="off">
						<div style="text-align: center;">
							<span><a href="send-staffs-list.php?contract=<?php echo $_GET['contract']; ?>&status=1" class="front_button" style="padding: 5px 15px;">Already Sent</a><span>
								<span><a href="send-staffs-list.php?contract=<?php echo $_GET['contract']; ?>&status=2" class="front_button" style="padding: 5px 15px;">Failed Sent</a><span>
									<span><a href="send-staffs-list.php?contract=<?php echo $_GET['contract']; ?>&status=0" class="front_button" style="padding: 5px 15px;">Never Attempted</a><span>
									</div>

									<table class="table table-bordered table-hover">
										<thead>
											<tr>
												<th class="text-center">#</th>
												<th class="text-center">Full Name</th>
												<th class="text-center">Email ID</th>
												<th class="text-center">Sent Status</th>
											</tr>
										</thead>
										<tbody>

											<?php
											$tbl_name="sent_contracts";
											$adjacents = 1;


											$asql1="select staff_id from sent_contracts where contract_id=".$_GET['contract'];
											$staff_ids = mysqli_query($con,$asql1);
											$send_staff_ids=array();
											while($row_1 = mysqli_fetch_array($staff_ids))
											{	
												$send_staff_ids[]=$row_1['staff_id'];
											}
											if(!empty($send_staff_ids)){
												$staff_ids_comm=implode(",", $send_staff_ids);
											}else{
												$staff_ids_comm="";
											}
//$sql="select * from staffs where staff_id NOT IN ($staff_ids_comm)";

											if(isset($_GET['status']) && $_GET['status']==0){
												$query="select COUNT(*) from staffs where staff_id NOT IN ($staff_ids_comm) order by staff_id  desc "; 
											}else{
												$query="SELECT COUNT(*) as num FROM  $tbl_name WHERE sent_status=".$_GET['status']." AND contract_id=".$_GET['contract']." order by ID  desc "; 
											}

											$total_pages = mysqli_fetch_array(mysqli_query($con,$query));
											$total_pages = $total_pages[num];
											$targetpage = "send-staffs-list.php?contract=".$_GET['contract']."&status=".$_GET['status'];
											$limit =20;
											$page = $_GET['page'];
											$limitvalue = $page * $limit - ($limit);  
											if($page) 
												$start = ($page - 1) * $limit;
											else
												$start = 0;
											$limitvalue = $page * $limit - ($limit);  


											if(isset($_GET['status']) && $_GET['status']==0){
												if(empty($staff_ids_comm)){
														$not_in="";
												}else{
														$not_in="NOT IN ($staff_ids_comm)";
												}
												$sql="select * from staffs where staff_id $not_in order by staff_id desc LIMIT $start, $limit ";
											}else{
												$sql="SELECT * FROM  $tbl_name WHERE sent_status=".$_GET['status']." AND contract_id=".$_GET['contract']." order by ID  desc LIMIT $start, $limit ";
											}
//print_r($sql);
											$result = mysqli_query($con,$sql);
											if ($page == 0) $page = 1;
											$prev = $page - 1;
											$next = $page + 1;	
											$lastpage = ceil($total_pages/$limit);
											$lpm1 = $lastpage - 1;
											$pagination = "";
											if($lastpage > 1)
											{	
												$pagination .= "<div class=\"pagination\">";
												if ($page > 1) 
													$pagination.= "<a href=\"$targetpage&page=$prev\">«</a>";
												else
													$pagination.= "<span class=\"disabled\">«</span>";	
												if ($lastpage < 7 + ($adjacents * 2))
												{	
													for ($counter = 1; $counter <= $lastpage; $counter++)
													{
														if ($counter == $page)
															$pagination.= "<span class=\"current\">$counter</span>";
														else
															$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
													}
												}
												elseif($lastpage > 5 + ($adjacents * 2))
												{
													if($page < 1 + ($adjacents * 2))		
													{
														for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
														{
															if ($counter == $page)
																$pagination.= "<span class=\"current\">$counter</span>";
															else
																$pagination.= "<a href=\"$targetpage&page=$counter \">$counter</a>";					
														}
														$pagination.= "<span style='color:#23B7E5'>...</span>";
														$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
														$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
													}
													elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
													{
														$pagination.= "<a href=\"$targetpage&page=1\">1</a>";
														$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
														$pagination.= "<span style='color:#23B7E5'>...</span>";
														for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
														{
															if ($counter == $page)
																$pagination.= "<span class=\"current\">$counter</span>";
															else
																$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
														}
														$pagination.= "<span style='color:#23B7E5'>...</span>";
														$pagination.= "<a href=\"$targetpage&page=$lpm1\">$lpm1</a>";
														$pagination.= "<a href=\"$targetpage&page=$lastpage\">$lastpage</a>";		
													}
													else
													{
														$pagination.= "<a href=\"$targetpage&page=1 \">1</a>";
														$pagination.= "<a href=\"$targetpage&page=2\">2</a>";
														$pagination.= "<span style='color:#23B7E5'>...</span>";
														for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
														{
															if ($counter == $page)
																$pagination.= "<span class=\"current\">$counter</span>";
															else
																$pagination.= "<a href=\"$targetpage&page=$counter\">$counter</a>";					
														}
													}
												}
												if ($page < $counter - 1) 
													$pagination.= "<a href=\"$targetpage&page=$next \">»</a>";
												else
													$pagination.= "<span class=\"disabled\">»</span>";
												$pagination.= "</div>\n";		
											}
											?>
											<?php
											$count = isset($_GET['page']) && $_GET['page'] > 1 ? $limitvalue : 0; 
											$num=mysqli_num_rows($result);
											if($num>0)
											{
												while($row = mysqli_fetch_array($result))
												{
													$count++; 
													?>
													<tr class="text-center tr<?php echo $row['ID']; ?>">
														<td style="width:1%;"><input type="checkbox" name="selected_staff[]" value="<?php echo $row['staff_id']; ?>"></td>
														<td><?php echo $row['fullname']; ?></a></td>
														<td><?php echo $row['email']; ?></td>
														<td style="width:1%;"><span id="like-panel-<?php echo $row['ID']; ?>">
															<?php
															if($row['sent_status']=='1')
															{
																echo "Sent";
															}
															elseif($row['sent_status']=='2'){
																echo "Failed";
															}else{
																echo "Not Attempted";
															}
															?>
														</span> </td>

													</tr>
													<?php
												}}else
												{ ?>
													<td style="padding:4px; text-align:center;" colspan="20" align="center"><b style="font-size:18px;color:#FF0000;">No Data Available!</b></td>
													<?php
												}
												?>
											</tbody>
										</table>
										<?php if($num>0){ ?>
											<button type="submit" class="btn btn-default front_button" name="send-contract" id="send-contract">Send Contract</button>
										<?php } ?>
									</form>
								</div>
								<div class="pagi" style="float:right;position:relative;">
									<?php echo $pagination; ?>
								</div>


							</div>

							<!-- content end -->
						</div>

					</div>

					<?php
					include "footer.php";
					?>

					<script type="text/javascript">

/*function validate_send_contract()
{

t = sendContractForm.selected_staff.value.trim();
if( t == ""){
document.getElementById('errmsg').innerHTML='Select a user.';
sendContractForm.selected_staff.focus();
return (false);
}

return true;

}	*/

</script>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
<script src="js/admin.js"></script>
</body>
</html>
