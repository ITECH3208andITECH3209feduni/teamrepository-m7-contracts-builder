<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
	header("Location: sign-in.php");
}
?>

<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
	
	<style type="text/css">
		.tox-notifications-container{
			display: none !important;
			visibility: hidden !important;
		}
	</style>
</head>
<body>

	<?php
	include "primary-menu.php";


	if( (isset($_GET['contractid']) && $_GET['action']=='edit') )
	{

		$sql1="select * from contracts where contract_id='".$_GET['contractid']."' ";
		$result1=mysqli_query($con,$sql1);
		$row1=mysqli_fetch_array($result1);

		$title=mysqli_real_escape_string($con,$row1['title']);
		$content=stripslashes($row1['content']);
		$attached_sign=$row1['attached_sign'];

		$button_value="updatecontract";

		$button_name="Update Contract";
		$form_title="Edit Contract";

	}else{

		$title="";
		$content="";
		$attached_sign="";

		$button_name="Add Contract";
		$form_title="Add Contract";
		$button_value="addcontract";

		$_GET['contractid']="";

	}

	if(isset($_POST['addcontract']))
	{
		$title=mysqli_real_escape_string($con,$_POST['title']);
		$content=addslashes($_POST['content']);

		$file_name="";
		if(isset($_FILES) && !empty($_FILES)){
					$file_name=upload_attached_file($_FILES);
		}else{

		}
		$pdf_name=generate_pdf($_POST['content'],$file_name);

		$sql ="INSERT INTO contracts (title, content,attached_sign, pdf) values('".$title."', '".$content."', '".$file_name."', '".$pdf_name."')";
		mysqli_query($con,$sql) or die(mysqli_error($con));
		$_SESSION['have_error']="Contract Added Successfully.";
		header('Location: contract-list.php');
		exit();
	}

	if(isset($_POST['updatecontract']))
	{
		$contractid = mysqli_real_escape_string($con,$_POST['contractid']);
		$title=mysqli_real_escape_string($con,$_POST['title']);
		$content = str_replace("\r\n",'',$_POST['content']);
		$content=addslashes($content);

		$file_name="";
		$attached_sign="";
		//print_r($_POST);
		if(isset($_FILES) && !empty($_FILES) && $_FILES["attached_file"]["tmp_name"]!==''){
					$file_name=upload_attached_file($_FILES);
					// $attached_sign=" attached_sign='$file_name',";
		}elseif( $_POST['image_remove']=="true" && isset($_FILES) && !empty($_FILES) && $_FILES["attached_file"]["tmp_name"]!==''){
					$file_name=upload_attached_file($_FILES);
					// $attached_sign=" attached_sign='$file_name',";
		}

		$pdf_name=generate_pdf($_POST['content'],$file_name);

		$sql = "UPDATE contracts SET title='$title', content='$content', attached_sign='$file_name', pdf='".$pdf_name."' WHERE contract_id='$contractid'";
		mysqli_query($con,$sql);

		$_SESSION['have_error']="Contract Updated Successfully.";
		// header('Location: contract-list.php');
		// exit();
	}

	function upload_attached_file($file){
		$target_dir = "uploads/";
		$target_file = $target_dir .time()."-".basename($file["attached_file"]["name"]);
		//print_r($target_file);
	if (move_uploaded_file($file["attached_file"]["tmp_name"], $target_file)) {
			return $target_file;
  } else {
  	return "";
  }

	}

// 	if(isset($_POST['content']) && !empty($_POST['content'])){
// 		$sql_contract="select * from contracts where contract_id='".$_GET['contractid']."' ";
// 		$result_contract=mysqli_query($con,$sql_contract);
// 		$row_contract=mysqli_fetch_array($result_contract);

// 		$attached_sign=$row_contract['attached_sign'];

		


// require('html2pdf.php');
// //	print($_POST['content']);exit;
// $aaaa = str_replace('</p>', '</p>', $_POST['content']);
// $aaaa = str_replace('&nbsp;', '', $aaaa);

// if(!empty($attached_sign)){
// 		$path =  BASEPATH.$attached_sign;
// 	 $aaaa = str_replace('{{AttachedSign}}', '<img width="100" src="'.$path.'" />', $aaaa);
// }


// $pdf=new PDF_HTML();
// $pdf->SetMargins(10,35,10);
// $pdf->SetAutoPageBreak(auto,30);
// $pdf->SetFont('Arial','',12);
// $pdf->AddPage();
// $pdf->WriteHTML($aaaa);
// $filename="pdf/".time().".pdf";
// //$pdf->Image('http://localhost/contract/code/sprint2/uploads/demo.jpg',0,0,-100,30);
// $pdf->Output($filename,'F');
// //$pdf->Output();
// //exit;
// }

function generate_pdf($content,$sign){
	require('html2pdf.php');
	$aaaa = str_replace('</p>', '</p>', $content);
	$aaaa = str_replace('&nbsp;', '', $aaaa);

	if(!empty($sign)){
			$path =  BASEPATH.$sign;
		 $aaaa = str_replace('{{AttachedSign}}', '<img width="100" src="'.$path.'" />', $aaaa);
	}


	$pdf=new PDF_HTML();
	$pdf->SetMargins(10,35,10);
	$pdf->SetAutoPageBreak(auto,30);
	$pdf->SetFont('Arial','',12);
	$pdf->AddPage();
	$pdf->WriteHTML($aaaa);
	$filename="pdf/".time().".pdf";
	$pdf->Output($filename,'F');

	return $filename;
}


	if(isset($_POST['updatecontract']))
	{
		header('Location: contract-list.php');
		exit();
	}
	?> 
	<div class="container">
		<div class="ls_content">
			<!-- content start -->

			<div class="row">

				<div class="col-md-12">

					<div class="ls_over_to_you ls_sign_in text-center" style="width: 100%;">
						<h1><?php echo $form_title; ?></h1>
						<div class="registration_form">
							<div>
								<p>Enter Details Below</p>
							</div>

							<form name="addContractForm" action="" onSubmit="return validate_contract();" method="post" enctype="multipart/form-data" autocomplete="off">
								<span id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;">
									<?php 
									if(isset($_SESSION['have_error']))
									{
										echo $_SESSION['have_error'];
										unset($_SESSION['have_error']);
									}
									?>
								</span>

								<?php if( isset($_GET['contractid']) && $_GET['contractid']!=null ) 
								{
									?>
									<input type="hidden" name="contractid" value="<?php echo $_GET['contractid']; ?>">
									<?php
								}
								?>
								<div class="form-group">
									<label for="title">Title:</label>
									<input type="text" class="form-control" name="title" id="title" placeholder="Contract" value="<?php echo $title; ?>">

										<div class="form-group">
												<input type="file" class="form-control" name="attached_file" style="float: left;width: 200px;margin-right: 10px;" value="<?php echo $attached_sign ?>">
												<input type="hidden"  name="image_remove" value="false">
												<?php if(!empty($attached_sign)){ ?>
												<div class="attached-sign-div"><i class="fa fa-times" aria-hidden="true"></i><img src="<?php echo BASEPATH.$attached_sign ?>" style="width:70px;float: left;" /></div>
												<?php } ?>
											</div>

									<div class="form-group" style="clear: both;">
										<?php 
									if( (isset($_GET['contractid']) && $_GET['action']=='edit') )
									{ ?>
										<textarea class="form-control" rows="40" name="content" id="content"><?php echo $content; ?></textarea>
									<?php
								}else{
									?>
									<textarea class="form-control" rows="40" name="content" id="content"><?php include 'default-text.html'; ?></textarea>
									<?php
								}
									?>
									</div>
								</div>
								<div class="form-group"><br>
									<p><b>NOTE: For adding user data in the pdf use the following :</b></p>
									<ul>
										<li>For User Name: <b>{{Name}}</b></li>
										<li>For User Email:<b> {{Email}}</b></li>
										<li>For Current Date: <b>{{CurrentDate}}</b></li>
										<li>For Attached sign: <b>{{AttachedSign}}</b></li>
										<li>For Staff sign: <b>{{StaffSign}}</b></li>
									</ul>
								</div>
								<button type="submit" class="btn btn-default front_button" name="<?php echo $button_value; ?>"><?php echo $button_name; ?></button>
							</form>

						</div>
					</div>


				</div>

			</div>

			<!-- content end -->
		</div>

	</div>

	<?php
	include "footer.php";
	?>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"></script>

	<script type="text/javascript">

		function validate_contract()
		{

			t = addContractForm.title.value.trim();
			if( t == ""){
				document.getElementById('errmsg').innerHTML='Enter Contract Title.';
				addContractForm.title.focus();
				return (false);
			}

/*t = addContractForm.content.value.trim();
if( t == ""){
document.getElementById('errmsg').innerHTML='Enter Contract Content';
addContractForm.content.focus();
return (false);
}*/
return true;
}

</script>

<script src="js/tinymce.min.js"></script>
	<script>tinymce.init({selector:'textarea',plugins: 'table,code'});</script>

<script src="js/admin.js"></script>
</body>
</html>
