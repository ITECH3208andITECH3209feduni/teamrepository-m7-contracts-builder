<?php
session_start();
include "inc/connection.php";
error_reporting(0);

/* STAFF START */
/* delete staff start */
if($_POST['action'] == 'delete_staff'){
	$qry = "DELETE FROM staffs WHERE staff_id='".$_POST['staff_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete staff start */

/* change admin staff start */
if($_POST['action'] == 'change_staff_status'){
	$staff_id = $_POST['staff_id'];
	$staff_status = $_POST['staff_status'];
	if($staff_status == "activate"){
		$qry="UPDATE staffs SET status='1'  WHERE staff_id='".$_POST['staff_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE staffs SET status='0'  WHERE staff_id='".$_POST['staff_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* change admin staff end */
/* STAFF END */


/* POSITION START */
/* delete position start */
if($_POST['action'] == 'delete_position'){
	$qry = "DELETE FROM positions WHERE position_id='".$_POST['position_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete position start */

/* change admin position start */
if($_POST['action'] == 'change_position_status'){
	$position_id = $_POST['position_id'];
	$position_status = $_POST['position_status'];
	if($position_status == "activate"){
		$qry="UPDATE positions SET status='1'  WHERE position_id='".$_POST['position_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE positions SET status='0'  WHERE position_id='".$_POST['position_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* change admin position end */
/* POSITION END */

/* CONTRACT START */
/* delete contract start */
if($_POST['action'] == 'delete_contract'){
	$qry = "DELETE FROM contracts WHERE contract_id='".$_POST['contract_id']."'";
	$result = mysqli_query($con,$qry) or die(mysqli_error($con));
	if($result){
		echo "1";
	}else{
		echo "0";
	}
	exit(0);
}
/* delete contract start */

/* change admin contract start */
if($_POST['action'] == 'change_contract_status'){
	$contract_id = $_POST['contract_id'];
	$contract_status = $_POST['contract_status'];
	if($contract_status == "activate"){
		$qry="UPDATE contracts SET status='1'  WHERE contract_id='".$_POST['contract_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "1";
	}else{
		$qry="UPDATE contracts SET status='0'  WHERE contract_id='".$_POST['contract_id']."'  ";
		$result=mysqli_query($con,$qry);
		echo "2";
	}
	exit(0);
}
/* change admin contract end */
/* CONTRACT END */



/* RESEND CONTRACT START */
if($_POST['action'] == 'resend_contract'){

require_once('PHPMailer/PHPMailerAutoload.php');
require_once('html2pdf.php');


$contract = isset($_POST['contract_id']) && !empty($_POST['contract_id']) ? $_POST['contract_id'] : "";

if(isset($contract) && !empty($contract)){
$pdfsql="select * from contracts where contract_id='".$contract."' ";
$pdfresult=mysqli_query($con,$pdfsql);
$pdfrow=mysqli_fetch_array($pdfresult);
$pcontent=stripslashes($pdfrow['content']);
$attached_sign=$pdfrow['attached_sign'];


$status = isset($_POST['status']) && !empty($_POST['status']) ? $_POST['status'] : "";

$stqry=" SELECT * FROM staffs WHERE staff_id=".$_POST['staff_id'];
$stres=mysqli_query($con, $stqry);
$strow = mysqli_fetch_array($stres);

$receiverEmail = $strow['email'];

$getqry=" SELECT smtpemail FROM admin WHERE role_id=4 ";
$getres=mysqli_query($con, $getqry);
$getrow=mysqli_fetch_array($getres);
$senderEmail =	$getrow['smtpemail'];
//$senderEmail =	'hemendray@lexcis.com';

$pdfContent = "";
//$pdfContent .= "<h2>".$strow['fullname']."</h2>";
$pdfContent .= $pcontent;
//$pdfContent .= "<hr><p>Staff Signature</p>";

$htmlData = str_replace('</p>', '</p>', $pdfContent);
$htmlData = str_replace('&nbsp;', '', $htmlData);
$htmlData = str_replace('{{Name}}', $strow['fullname'], $htmlData);
$htmlData = str_replace('{{Full Name}}', $strow['fullname'], $htmlData);
$htmlData = str_replace('{{Email}}', $strow['email'], $htmlData);
$htmlData = str_replace('{{CurrentDate}}', date("Y-m-d"), $htmlData);

if(!empty($attached_sign)){
					$path =  BASEPATH.$attached_sign;
					$htmlData = str_replace('{{AttachedSign}}', '<img width="100" src="'.$path.'" />', $htmlData);
}

$pdf=new PDF_HTML();
$pdf->SetMargins(10,35,10);
$pdf->SetAutoPageBreak(auto,30);
$pdf->SetFont('Arial','',12);
$pdf->AddPage();
$pdf->WriteHTML($htmlData);
$filename="sent-pdf/".$receiverEmail.".pdf";
$pdf->Output($filename,'F');
//$pdf->Output();
//exit;

$randomNumber = rand();
$unique_id = md5($randomNumber);

if(isset($_SERVER['HTTPS'])){
$protocol = ($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http";
}else{
$protocol = 'http';
}
$my_site_url = $protocol."://".$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"].'?').'/';
$resetURL = $my_site_url."sign-contract.php?key=".$randomNumber."&action=sign-contract";

$to = $receiverEmail;
$subject = "Contract for Sign";
$message = "<h3>Hello ".$strow['fullname'].",</h3>
<p>Please click the below link to reset your password:<br>
<a href='".$resetURL."' target='_blank'>".$resetURL."</a>
</p>";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From : ".$senderEmail."";
$mail = new PHPMailer(true);
$mail->AddAttachment($filename, $receiverEmail.'.pdf');

if( mail($to, $subject, $message, $headers) ){

if(isset($status) && $status==0){
		mysqli_query($con, " INSERT INTO sent_contracts (contract_id, staff_id, fullname, email, contract_pdf, unique_id, is_signed, sent_status) values('".$contract."', '".$strow['staff_id']."', '".$strow['fullname']."', '".$strow['email']."', '".$filename."', '".$unique_id."', '0', '1') ");
		mysqli_query($con, " UPDATE staffs SET sent_status='1' WHERE staff_id='".$strow['staff_id']."' ");
	}elseif(isset($status) && ( $status==1 || $status==2 ) ){
		mysqli_query($con, " UPDATE sent_contracts SET contract_id='".$contract."', is_signed='0', sent_status='1', contract_pdf='".$filename."', unique_id='".$unique_id."' WHERE staff_id='".$strow['staff_id']."' ");
	}
echo '1';exit;
}else{

	if(isset($status) && $status==0){
		mysqli_query($con, " INSERT INTO sent_contracts (contract_id, staff_id, fullname, email, sent_status) values('".$contract."', '".$strow['staff_id']."', '".$strow['fullname']."', '".$strow['email']."', '2') ");
		//mysqli_query($con, " INSERT INTO sent_contracts (contract_id, staff_id, fullname, email, contract_pdf, unique_id, is_signed, sent_status) values('".$contract."', '".$strow['staff_id']."', '".$strow['fullname']."', '".$strow['email']."', '".$filename."', '".$unique_id."', '0', '1') ");
		mysqli_query($con, " UPDATE staffs SET sent_status='1' WHERE staff_id='".$strow['staff_id']."' ");
	}elseif(isset($status) && ( $status==1 || $status==2 ) ){
		mysqli_query($con, " UPDATE sent_contracts SET contract_pdf = NULL, unique_id = NULL, is_signed = NULL, sent_status='2' WHERE staff_id='".$strow['staff_id']."' ");
		//mysqli_query($con, " UPDATE sent_contracts SET contract_id='".$contract."', is_signed='0', sent_status='1', contract_pdf='".$filename."', unique_id='".$unique_id."' WHERE staff_id='".$strow['staff_id']."' ");
	}


}
}
echo '0';exit;

}
/* RESEND CONTRACT END */


?>