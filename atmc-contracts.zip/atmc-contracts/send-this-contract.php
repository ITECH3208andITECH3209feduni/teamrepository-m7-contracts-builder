<?php
session_start();
error_reporting(0);
include "inc/connection.php";
if( !isset($_SESSION['admin_id']) )
{
header("Location: sign-in.php");
}
?>
<?php    
$sql="SELECT * FROM  contracts  WHERE contract_id='".$_GET['contractid']."'";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_array($result);
?>
<table width="98%" border="0" align="center" cellpadding="1" cellspacing="1">
<tr>
<td  align="left" class="toprk" >
<div style="padding: 25px; text-align: center;">
<h3><?php echo $row['title']; ?></h3><br>
<p>Please select from the below whom you want send this contract :</p>

<span><a href="send-staffs-list.php?contract=<?php echo $_GET['contractid']; ?>&status=1" class="front_button">Already Sent</a><span>
<span><a href="send-staffs-list.php?contract=<?php echo $_GET['contractid']; ?>&status=2" class="front_button">Failed Sent</a><span>
<span><a href="send-staffs-list.php?contract=<?php echo $_GET['contractid']; ?>&status=0" class="front_button">Never Attempted</a><span>

</div>
</td>
</tr>
</table>
