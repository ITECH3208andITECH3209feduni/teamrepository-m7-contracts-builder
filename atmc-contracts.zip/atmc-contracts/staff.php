<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( !isset($_SESSION['admin_id']) )
{
header("Location: sign-in.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
</head>
<body>

	<?php
	include "primary-menu.php";


if( (isset($_GET['staffid']) && $_GET['action']=='edit') || $_GET['action']=='editprofile' ) //If action EDIT
{

	if($_GET['action']=='edit'){
		$sql1="select * from staffs where staff_id='".$_GET['staffid']."' ";
	}else{
		$sql1="select * from staffs where staff_id='".$_SESSION['staff_id']."' ";
	}

	$result1=mysqli_query($con,$sql1);
	$row1=mysqli_fetch_array($result1);

	$position=mysqli_real_escape_string($con,$row1['position_id']);
	$fullname=mysqli_real_escape_string($con,$row1['fullname']);
	$email=mysqli_real_escape_string($con,$row1['email']);
	$address=mysqli_real_escape_string($con,$row1['address']);
	$entitle=mysqli_real_escape_string($con,$row1['entitle']);
	$profile_pic=mysqli_real_escape_string($con,trim($row1['profile_pic']));
	$password='';

	$button_value="updatestaff";

	if($_SESSION['staff_id'] != $_GET['staffid']){
		$button_name="Update Staff";
		$form_title="Edit Staff";
	}else{
		$button_name="Update Profile";
		$form_title="Edit Profile";
	}

	if($_SESSION['staff_position']=="admin"){
		$form_title="Edit Staff";
	}else{
		$form_title="Edit Profile";
	}


}else{

	if($_SESSION['staff_position']=="admin"){
		$position="";
		$form_title="Add Staff";
	}else{
		$form_title="Add Staff";
		$sql1="select * from staffs where staff_id='".$_SESSION['staff_id']."' ";
		$result1=mysqli_query($con,$sql1);
		$row1=mysqli_fetch_array($result1);
		$position=mysqli_real_escape_string($con,$row1['position_id']);
	}


	$fullname='';
	$email='';
	$password='';
	$profile_pic='';

	$button_name="Add Staff";
	$button_value="addstaff";


	$_GET['staffid']="";

}

if(isset($_POST['addstaff']))
{

//
	$checkrow=mysqli_fetch_array(mysqli_query($con,"select staff_id from staffs where email='".$_POST['email']."'"));
	if(count($checkrow) > 0)
	{
		$_SESSION['have_error']="Staff with the same Email ID already exist.";
		header('Location: staffs-list.php');
		exit();
	}
//

	$position=mysqli_real_escape_string($con,$_POST['position_id']);
	$fullname=mysqli_real_escape_string($con,$_POST['fullname']);
	$email=mysqli_real_escape_string($con,$_POST['email']);
	$address=mysqli_real_escape_string($con,$_POST['address']);
	$entitle=mysqli_real_escape_string($con,$_POST['entitle']);


	$sql ="INSERT INTO staffs (fullname, email, position_id, address, entitle, status) values('".$fullname."', '".$email."', '".$position."', '".$address."', '".$entitle."', '1')";
	mysqli_query($con,$sql) or die(mysqli_error($con));
	$cid = mysqli_insert_id();
	$_SESSION['have_error']="Staff Added Successfully.";
	header('Location: staffs-list.php');
	exit();
}

if(isset($_POST['updatestaff']))
{
	$id=intval($_GET['staffid']);
	$fullname=mysqli_real_escape_string($con,$_POST['fullname']);
	$email=mysqli_real_escape_string($con,$_POST['email']);
	$address=mysqli_real_escape_string($con,$_POST['address']);
	$entitle=mysqli_real_escape_string($con,$_POST['entitle']);
	$position=mysqli_real_escape_string($con,$_POST['position_id']);

//
	$checkrow=mysqli_fetch_array(mysqli_query($con,"select staff_id from staffs where email='".$_POST['email']."' AND staff_id!='".$id."' "));
	if(count($checkrow) > 0)
	{
		$_SESSION['have_error']="Staff with the same Email ID already exist.";
		header('Location: staffs-list.php');
		exit();
	}
//

	if(!empty($email)){
		$sql = "UPDATE staffs SET email='$email' WHERE staff_id='$id'";
		mysqli_query($con,$sql);
	}

	$sql = "UPDATE staffs SET position_id='$position', fullname='$fullname', address='$address', entitle='$entitle' WHERE staff_id='$id'";
	mysqli_query($con,$sql);

/*	if( $_SESSION['staff_position']!='admin' && $_SESSION['staff_id']==$id ){
		$_SESSION['have_error']="Profile Updated Successfully.";
		header('Location: dashboard.php');
	}else{*/
		$_SESSION['have_error']="Staff Updated Successfully.";
		header('Location: staffs-list.php');
	//}

	exit();
}
?> 
<div class="container">
	<div class="ls_content">
		<!-- content start -->

		<div class="row">

			<div class="col-md-8 col-md-offset-2">

				<div class="ls_over_to_you ls_sign_in text-center">
					<h1><?php echo $form_title; ?></h1>
					<div class="registration_form">
						<div>
							<p>Enter Details Below</p>
						</div>


						<form  name="addStaffform" id="addform" onSubmit="return validate_staff_form();" action="" method="post" enctype="multipart/form-data" autocomplete="off">
							<div id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;"> </div>

							<?php if( isset($_GET['staffid']) && $_GET['staffid']!=null ) 
							{ ?>
								<input type="hidden" name="position_id" value="<?php echo $position; ?>">
							<?php }else{ ?>
								<input type="hidden" name="type" value="1">
							<?php } ?>

							<div class="form-group">
								<label>Position</label>
								<select class="form-control" name="position_id" id="position_id">
									<option value="">-- Select Position --</option>
									<?php
									$positionqry="select * from positions where status='1' order by position ASC";
									$positionres=mysqli_query($con,$positionqry);
									while($positionrow=mysqli_fetch_array($positionres)){
										?>
										<option value="<?php echo $positionrow['position_id']; ?>"<?php if($position==$positionrow['position_id']){ echo "selected";} ?>><?php echo $positionrow['position']; ?></option>
									<?php } ?>
								</select>
							</div>

							<div class="form-group">
								<label>Fullname</label>
								<input class="form-control" type="text" placeholder="Fullname" name="fullname" id="fullname" value="<?php echo $fullname; ?>" maxlength="100">
							</div>

							<div class="form-group">
								<label>Email ID</label>
								<input class="form-control" type="text" placeholder="Email ID" name="email" id="email" value="<?php echo $email; ?>" maxlength="100">
							</div>

							<div class="form-group">
								<label>Address</label>
								<textarea class="form-control" placeholder="Address" name="address" id="address"><?php echo $address; ?></textarea>
							</div>

							<div class="form-group">
								<label>Entitle</label>
								<input class="form-control" type="text" placeholder="Entitle" name="entitle" id="entitle" value="<?php echo $entitle; ?>" maxlength="100">
							</div>

							<button type="submit" class="btn btn-default front_button"  name="<?php echo $button_value; ?>" id="<?php echo $button_value; ?>" value="<?php echo $button_value; ?>"><?php echo $button_name; ?></button>


						</form>


					</div>
				</div>


			</div>

		</div>

		<!-- content end -->
	</div>

</div>

<?php
include "footer.php";
?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>

<script type="text/javascript"> // ADD START

function validate_staff_form()
{



	t = addStaffform.position_id.value.trim();
	if( t == ""){
		document.getElementById('errmsg').innerHTML='Select Position.';
		addStaffform.position_id.focus();
		return (false);
	}

	t = addStaffform.fullname.value.trim();
	if( t == ""){
		document.getElementById('errmsg').innerHTML='Enter Fullname.';
		addStaffform.fullname.focus();
		return (false);
	}

	<?php //if($_GET['staffid']==null){ ?>
		t = addStaffform.email.value.trim();
		if( t == ""){
			document.getElementById('errmsg').innerHTML='Enter Email ID.';
			addStaffform.email.focus();
			return (false);
		}

		t = addStaffform.email.value.trim();
		emailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/; 
		if (!t.match(emailformat)) 
		{
			document.getElementById('errmsg').innerHTML='Enter a valid Email ID.';
			addStaffform.email.focus();
			return false;
		}

		<?php //} ?>

		return true;

}				// ADD END
</script>

</body>
</html>
