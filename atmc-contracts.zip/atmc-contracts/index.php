<?php
session_start();
include "inc/connection.php";
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
<?php include "head.php"; ?>
</head>
<body>

	<?php
	
	include "primary-menu.php";
	?> 
	<div class="container">
<!-- 		<div class="welcome">
			<h1>THIS IS HOME PAGE</h1>
		</div> -->
		<div class="ls_content">
		<!-- content start -->

		<div class="row">
			<div class="col-md-12 ls_get_started_main">
				<div class="col-md-6">
					<div class="ls_get_started">
					<h1>Lorem ipsum dolor sit amet</h1>
					<p>RecConsectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
commodo consequat.</p>
					<a href="#" style="width: auto;" class="front_button">Click</a>
					</div>

				</div>
				<div class="col-md-6"></div>

			</div>
			
			<!-- <div class="ls_home_acc_box">
			<div class="col-md-6">
				<div class="ls_home_acc">
					<img src="images/admin.png">
					<a href="./admin" class="front_button">Super Admin Login</a>
				</div>
			</div>

			<div class="col-md-6">
				<div class="ls_home_acc">
									<img src="images/staff.png">
					<a href="./admin/staff-login.php" class="front_button">Admin/Staff Login</a>
				</div>
			</div>

			</div> -->


			<div class="col-md-12">

					<div class="ls_powerful_soft text-center">
					<h1>Lorem ipsum dolor sit amet</h1>
					<p>RecConsectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
aliqua</p>

					<div class="powerful-container">

					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="powerful-box">
							<h3>Lorem ipsum dolor sit amet</h3>
							<p>RecConsectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
aliqua</p>
							<a href="#" style="width: auto;" class="front_button">Click</a>
						</div>
					</div>

					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="powerful-box">
							<h3>Lorem ipsum dolor sit amet</h3>
							<p>RecConsectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
aliqua</p>
							<a href="#" style="width: auto;" class="front_button">Click</a>
						</div>
					</div>

					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="powerful-box">
							<h3>Lorem ipsum dolor sit amet</h3>
							<p>RecConsectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
aliqua</p>
							<a href="#" style="width: auto;" class="front_button">Click</a>
						</div>
					</div>

					</div>
					
					</div>


			</div>

			<div class="col-md-8 col-md-offset-2">

					<div class="ls_over_to_you text-center">
					<h1>Lorem ipsum</h1>
					<p>RecConsectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
aliqua.</p>
					<a href="#" style="width: auto;" class="front_button">Click</a>
					</div>


			</div>
			

		</div>

		<!-- content end -->
	</div>

</div>

<?php
include "footer.php";
?>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
