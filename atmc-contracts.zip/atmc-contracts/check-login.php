<?php
session_start();
include "inc/connection.php";
?>
<?php 
$email=mysqli_real_escape_string($con,$_POST['email']);
$password=mysqli_real_escape_string($con,$_POST['password']);
if(isset($_POST['email']) && isset($_POST['password'])) 
{
	$qry=" SELECT * FROM admin WHERE (email='".$email."' OR fullname='".$email."') AND password='".md5($password)."'";
	$res=mysqli_query($con, $qry);
	$row=mysqli_fetch_array($res);
	if($row!=""){
		if($row['status'] == 1){

			if(isset($_POST['remember_me']) && !empty($_POST['remember_me'])){
				setcookie('cEmail', $email, time() + (86400 * 30), "/");
				setcookie('cPassword', $password, time() + (86400 * 30), "/");
			}else{
				setcookie('cEmail', "", time() + (5), "/");
				setcookie('cEmail', "", time() + (5), "/");
			}

			$_SESSION['admin_id'] = $row['member_id'];
			$_SESSION['admin_name']=$row['fullname'];
			$_SESSION['admin_email'] = $row['email'];

			header('Location: index.php');
		}else{
			$_SESSION['have_error']="Your account is deactivated.";
			header('Location: sign-in.php');
		}

	}else{
		$_SESSION['have_error']="Invalid login details!";
		header('Location: sign-in.php');
	}
}
?>