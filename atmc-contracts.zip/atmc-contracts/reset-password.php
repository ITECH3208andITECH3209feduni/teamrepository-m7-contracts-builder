<?php
session_start();
include "inc/connection.php";
error_reporting(0);
if( isset($_SESSION['admin_id']) && !isset($_GET['key']) )
{
header("Location: vacancies-applied.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include "head.php"; ?>
</head>
<body>

	<?php
	include "primary-menu.php";


	if(isset($_GET['key']) && $_GET['action']=='reset-password' ) 
	{
		$canQuery="SELECT * FROM members where unique_id='".md5($_GET['key'])."' ";
		$canRes=mysqli_query($con,$canQuery);
		$canRow=mysqli_fetch_array($canRes);
		if(!$canRow){
			$_SESSION['have_error']="Reset password link has expired.";
			header('Location: forgot-password.php');
			exit;
		}

		$form_name = "Reset Password";
		$button_name = "Submit";
		$button_value = "resetpassword";
	}else{
		header('Location: sign-in.php');
	}

	?> 
	<div class="container">
		<div class="ls_content">
		<!-- content start -->

		<div class="row">

			<div class="col-md-8 col-md-offset-2">

				<div class="ls_over_to_you ls_sign_in text-center">
					<h1><?php echo $form_name; ?></h1>
					<div class="registration_form">
						<div>
							<p>Enter new password.</p>
						</div>

						<form name="cResetPasswordForm" action="check-login-candidate.php" onSubmit="return validate_sign_up();" method="post" enctype="multipart/form-data" autocomplete="off">
							<span id="errmsg" style="font-size:12px;color:#F00;margin-bottom:10px;">
								<?php 
								if(isset($_SESSION['have_error']))
								{
									echo $_SESSION['have_error'];
									unset($_SESSION['have_error']);
								}
								?>
							</span>
							<input type="hidden" name="unique_key" value="<?php echo $_GET['key']; ?>">
							<div class="form-group">
								<label for="password">New Password:</label>
								<input type="password" class="form-control" name="password" id="password" placeholder="New Password" value="">
							</div>

							<div class="form-group">
								<label for="confirmpassword">Confirm Password:</label>
								<input type="password" class="form-control" name="confirmpassword" id="confirmpassword" placeholder="Confirm Password" value="">
							</div>

							<button type="submit" class="btn btn-default front_button" name="<?php echo $button_value; ?>"><?php echo $button_name; ?></button>
						</form>

					</div>
				</div>


			</div>

		</div>

		<!-- content end -->
	</div>

	</div>

	<?php
	include "footer.php";
	?>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/script.js"></script>

	<script type="text/javascript">

		function validate_sign_up()
		{

			var newpassword = cResetPasswordForm.password.value.trim();
			if( newpassword == ""){
				document.getElementById('errmsg').innerHTML='Enter New Password.';
				cResetPasswordForm.password.focus();
				return (false);
			}

			var confirmpassword = cResetPasswordForm.confirmpassword.value.trim();
			if( confirmpassword == ""){
				document.getElementById('errmsg').innerHTML='Enter Confirm Password.';
				cResetPasswordForm.confirmpassword.focus();
				return (false);
			}

			if( newpassword != confirmpassword ){
				document.getElementById('errmsg').innerHTML='New Password and Confirm Password didn\'t match.';
				cResetPasswordForm.confirmpassword.focus();
				return (false);
			}

			return true;

		}	

	</script>

</body>
</html>
